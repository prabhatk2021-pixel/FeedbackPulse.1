# FeedbackPulse

**Every voice, a possibility.** A complete, interactive customer-feedback hub built with Next.js App Router, TypeScript, Tailwind CSS, and Lucide. Designed as a recruiter-ready, production-shaped **demo**, with a real same-origin API and deliberately simulated external integrations.

## Run locally

Requires Node.js 20.19+ and npm. No environment variables, database, Stripe credentials, or AI API keys are required.

```bash
npm ci
npm run dev
```

Open **http://localhost:3000**. For a production build:

```bash
npm run build
npm start
```

The server listens on `0.0.0.0` and works behind a preview proxy. All application requests use relative URLs. DM Sans is bundled locally; no runtime font/CDN dependencies.

## A two-minute product tour

1. **Overview** — review workspace metrics, sentiment trends, recent feedback, and live counts. Try a date range or export a CSV.
2. **Feedback widget** — submit a message with an email, rating, category, title, and details. Field validation is immediate after interaction. The message appears in the inbox without a reload.
3. **Feedback inbox** — search, combine category/sentiment/status filters, switch table/Kanban views, inspect a message, change its status, or bulk-update selected rows.
4. **AI Triage & Categorize** — classify untriaged messages with a deterministic, keyword-based mock classifier and realistic loading states. It never calls an LLM.
5. **Developers** — copy the working JavaScript or React embed, rotate the public workspace token, save webhook settings, and simulate a Slack/Discord payload delivery.
6. **Explore Pro** — open the pricing dialog and simulate Checkout. Success updates the plan; cancellation leaves it unchanged. Visit Analytics to see the Pro-gated resolution panel.
7. **Workspace switcher** — move between Acme Studio (14 seed messages) and Acme Labs (1 message). Feedback, tokens, and webhook settings are workspace-scoped.

## Routes

| Route          | Purpose                                                                  |
| -------------- | ------------------------------------------------------------------------ |
| `/`            | Overview, activity chart, statistics, recent feedback                    |
| `/feedback`    | Full inbox, combined filters, pagination, sorting, Kanban, bulk actions  |
| `/analytics`   | Sentiment activity, category distribution, Pro resolution analytics      |
| `/widget-demo` | Interactive end-user widget in desktop/mobile product previews           |
| `/developers`  | Embed snippets, API token, webhook settings and simulator                |
| `/settings`    | Editable profile, workspace details, subscription                        |
| `/billing`     | Mock hosted Checkout, `?status=success` and `?status=cancelled` outcomes |

## Architecture

```text
app/
  layout.tsx              Server-rendered initial database and clock snapshot
  api/store/route.ts      Demo admin snapshot / validated command API
  api/feedback/route.ts   Public, token-scoped feedback ingestion
  .../page.tsx           Thin route entrypoints
components/
  provider.tsx           Shared state, serialized mutations, background sync, toasts
  shell.tsx              Navigation, workspace switcher, search, notifications
  dashboard.tsx          Overview/inbox/analytics composition, CSV export, triage
  analytics.tsx          Data-derived SVG charts, cards and gated insights
  feedback-hub.tsx       Filtering, table, Kanban, selection, detail dialog
  feedback-form.tsx      Shared validated submission form and success state
  widget-demo.tsx        Embeddable widget simulator
  developers.tsx         Snippets, token management, webhook simulation
  billing.tsx            Pricing dialog and simulated checkout
  settings.tsx           Profile and workspace configuration
  ui.tsx                 Accessible dialog, buttons, badges, empty states
lib/
  types.ts               Domain interfaces and discriminated command union
  seed.ts                Diverse, relative-date seed fixtures
  store.ts               Pure immutable state transitions, Zod schemas, mock DB
  http.ts                Streaming request-size guard and submission rate limit
  *.test.ts              Domain and HTTP unit tests
public/
  widget.js              Standalone, dependency-free Shadow DOM embed
  fonts/                 Self-hosted DM Sans and its SIL Open Font License
 tests/app.spec.ts        Browser integration tests
```

### State and synchronization

The mock database is a **process-local, typed, in-memory singleton**, simulating a repository backed by Prisma/PostgreSQL. Its initial snapshot is passed from the server to the client, along with a stable clock, avoiding hydration differences. All mutations pass through a Zod-validated command endpoint. `applyCommand` clones the database, applies an atomic transition, and returns the new state; failed commands do not partially mutate the database.

React Context makes successful changes immediately visible across routes. Mutations are queued to avoid out-of-order local writes. Background requests cannot overwrite an in-flight mutation. Other browser tabs and external widget submissions are picked up on window focus or the 15-second poll. Only the selected workspace is stored in `localStorage`; business data is not.

All headline statistics, trend points, mini histograms, category distributions, and resolution rates derive from the current feedback items. Date range filters are rolling periods; chart dates are displayed in UTC. The summary is a rules-based mock, not a live AI service.

### API

- `GET /api/store` — full demo database snapshot; not cached.
- `POST /api/store` — one validated command: `submit`, `status`, `triage`, `webhook`, `upgrade`, `profile`, or `rotateKey`.
- `POST /api/feedback` — submit feedback with a public workspace token in `X-API-Key`.
- `OPTIONS /api/feedback` — CORS preflight for externally embedded widgets.

Example public submission using the initial demo token (copy the current token from Developers if it has been rotated):

```bash
curl http://localhost:3000/api/feedback \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: fp_demo_acme_7e94f3b8' \
  -d '{
    "customerEmail": "sam@example.com",
    "title": "Keyboard shortcuts would help",
    "content": "Please add a shortcut for jumping straight to my feedback inbox.",
    "category": "Feature Request",
    "rating": 4
  }'
```

The server resolves the workspace from the token; a supplied workspace ID cannot redirect the submission. Successful submissions return `201` with an ID. Invalid JSON/fields return `400`, invalid tokens `401`, oversized bodies `413`, unsupported content types `415`, and submission limits `429`. The public ingest endpoint accepts at most 30 requests per workspace per minute, within one server process. Both POST endpoints enforce a streamed 16 KB JSON body limit.

### Working embed

The Developers screen generates code for the current application origin and workspace token. The standalone script mounts an isolated Shadow DOM widget, performs validation, calls the public ingestion endpoint, and shows loading/error/success states. A public submission token is intentionally visible to visitors; it is not an admin credential. Token rotation invalidates existing embeds until they are updated.

The React snippet includes cleanup for both the script and the mounted widget. The embedding site must allow the application origin in its `script-src` and `connect-src` CSP directives, and permit the widget’s inline Shadow DOM styles. The live preview host must remain running; use a stable deployment URL for a persistent installation.

## Quality checks

```bash
npm run typecheck
npm test
npm run build
npm run format:check

# One-time browser installation; on Linux this may install system dependencies.
npx playwright install --with-deps chromium
npm run test:e2e
```

- **12 unit tests:** validation, categories, immutable/atomic mutations, workspace isolation, triage, upgrades, token rotation, payload bounds, and submission quotas.
- **6 browser tests:** filters, table/Kanban, workspace selection, widget validation/submission, triage/status changes, developer settings, checkout success/cancel, actual external script ingestion, and mobile navigation/overflow.
- TypeScript strict mode includes unused import/parameter checks.
- Playwright starts a dev server automatically, or reuses an existing server on port 3000. Tests mutate the shared demo. Restart the server afterward to restore seed data. A pre-existing Pro plan is supported by the repeatable billing test; start with fresh seed data to exercise the upgrade itself.
- Native dialogs provide focus trapping and Escape dismissal. Form controls have labels/errors, ratings support arrow-key navigation, status badges include text, icon-only controls have accessible names, and reduced-motion preferences are respected. The app is not represented as formally WCAG-certified.

## Honest demo boundaries

This repository is executable and complete for the requested **mock workflows**. It is **not safe to expose as a production customer-data service without the changes below**:

- No authentication or authorization: all users of one server share the demo owner, plan, and store. `/api/store` is intentionally an open demo admin surface. Same-origin checks are not authentication.
- The store resets on server restart, is not durable, and is not shared across replicas/serverless processes. Use a single long-lived Node process for this demo.
- AI classification is deterministic keyword matching after a simulated delay. It has no model inference, semantic understanding, or accuracy guarantee.
- Webhook tests generate provider-shaped JSON and a simulated `200 OK`. **No outbound request is sent.** Saved enabled events are configuration only, not an automatic delivery engine.
- Checkout does not load Stripe or collect card details. It waits, changes the mock plan, and redirects to a result state. Visiting a success URL alone does not change the plan.
- Prices and plan limits are illustrative. Resolution analytics is gated; core widget, triage, developer, and export workflows remain explorable on Free.
- Widget color selection is a preview-only setting, explicitly labeled as such.
- Never enter real personal information, payment details, secret webhook credentials, or production API keys.

## Path to a real production service

1. Replace the in-memory adapter with Prisma/PostgreSQL, migrations, tenant-scoped queries, durable transactions, and indexes on `(workspaceId, createdAt)` and `(workspaceId, status)`.
2. Add session authentication, workspace memberships, RBAC, server-side authorization for every command, anti-CSRF protection, audit logs, and secure secret storage. Remove the full-database snapshot endpoint.
3. Move triage to a background queue with idempotency, retry/backoff, a structured-output LLM adapter, confidence thresholds, and prompt-injection-aware separation of user text from instructions.
4. Deliver webhooks through a durable outbox worker with SSRF protection, HMAC signing, timeouts, dead-letter queues, and destination allowlists.
5. Create Stripe Checkout sessions server-side. Verify signed Stripe events and reconcile billing state from webhooks; do not trust client commands or redirect query parameters.
6. Use a shared rate-limit store, origin policies, abuse/spam controls, monitoring, centralized logging, backups, retention/deletion policies, and deployment-specific CSP. Replace polling with subscriptions if required at scale.

These are explicit architectural seams, not hidden unfinished features or placeholder implementation blocks.
