import test from "node:test";
import assert from "node:assert/strict";
import { applyCommand, classify, commandSchema } from "./store";
import { createSeed } from "./seed";

test("seed includes diverse feedback and isolated workspaces", () => {
  const db = createSeed();
  assert.ok(db.feedback.length >= 6);
  assert.equal(new Set(db.feedback.map((f) => f.category)).size, 4);
  assert.equal(db.workspaces.length, 2);
});
test("validated submission creates an inbox item without mutating source", () => {
  const db = createSeed();
  const command = commandSchema.parse({
    type: "submit",
    workspaceId: "ws_acme",
    customerEmail: "dev@example.com",
    title: "Please add shortcuts",
    content: "Keyboard shortcuts would be helpful for the whole team.",
    category: "Feature Request",
    rating: 4,
  });
  const next = applyCommand(db, command);
  assert.equal(next.feedback.length, db.feedback.length + 1);
  assert.equal(next.feedback[0].status, "Inbox");
  assert.equal(next.feedback[0].sentiment, "Positive");
  assert.equal(next.feedback[0].triaged, false);
});
test("rejects invalid fields at the API boundary", () => {
  assert.equal(
    commandSchema.safeParse({
      type: "submit",
      workspaceId: "ws_acme",
      customerEmail: "invalid",
      title: "Hi",
      content: "short",
      category: "Other",
      rating: 7,
    }).success,
    false,
  );
  assert.equal(
    commandSchema.safeParse({
      type: "status",
      ids: ["fb_001"],
      status: "Deleted",
    }).success,
    false,
  );
});
test("status mutations and bulk updates are atomic", () => {
  const db = createSeed();
  const next = applyCommand(db, {
    type: "status",
    ids: ["fb_001", "fb_002"],
    status: "Resolved",
  });
  assert.equal(next.feedback[0].status, "Resolved");
  assert.equal(next.feedback[1].status, "Resolved");
  assert.equal(db.feedback[0].status, "Inbox");
  assert.throws(() =>
    applyCommand(db, {
      type: "status",
      ids: ["fb_001", "missing"],
      status: "Resolved",
    }),
  );
  assert.equal(db.feedback[0].status, "Inbox");
});
test("triage only processes untriaged feedback in active workspace", () => {
  const db = createSeed();
  const next = applyCommand(db, { type: "triage", workspaceId: "ws_acme" });
  assert.ok(
    next.feedback
      .filter((f) => f.workspaceId === "ws_acme")
      .every((f) => f.triaged),
  );
  assert.equal(next.feedback.find((f) => f.id === "fb_labs")?.triaged, false);
});
test("deterministic classifier handles bugs, features, praise and UX", () => {
  assert.deepEqual(classify("Export is broken and blocking work"), {
    category: "Bug",
    sentiment: "Negative",
  });
  assert.equal(
    classify("Would love a dark mode option").category,
    "Feature Request",
  );
  assert.deepEqual(classify("Amazing product, excellent work!"), {
    category: "Praise",
    sentiment: "Positive",
  });
  assert.deepEqual(classify("Navigation is confusing"), {
    category: "UX Issue",
    sentiment: "Negative",
  });
});
test("checkout upgrades without side effects on feedback", () => {
  const db = createSeed();
  const next = applyCommand(db, { type: "upgrade" });
  assert.equal(next.user.plan, "Pro");
  assert.equal(db.user.plan, "Free");
  assert.deepEqual(next.feedback, db.feedback);
});
test("webhook settings reject insecure endpoints and arbitrary events", () => {
  const settings = {
    workspaceId: "ws_acme",
    provider: "Slack",
    url: "http://example.com/hook",
    enabledEvents: ["feedback.created"],
  };
  assert.equal(
    commandSchema.safeParse({ type: "webhook", settings }).success,
    false,
  );
  settings.url = "https://example.com/hook";
  assert.equal(
    commandSchema.safeParse({ type: "webhook", settings }).success,
    true,
  );
  settings.enabledEvents = ["arbitrary.event"];
  assert.equal(
    commandSchema.safeParse({ type: "webhook", settings }).success,
    false,
  );
});
test("token rotation changes only the intended workspace", () => {
  const db = createSeed();
  const next = applyCommand(db, { type: "rotateKey", workspaceId: "ws_acme" });
  assert.notEqual(next.workspaces[0].apiKey, db.workspaces[0].apiKey);
  assert.equal(next.workspaces[1].apiKey, db.workspaces[1].apiKey);
});
test("unknown workspaces cannot receive submissions or triage", () => {
  assert.throws(() =>
    applyCommand(createSeed(), { type: "triage", workspaceId: "missing" }),
  );
});
