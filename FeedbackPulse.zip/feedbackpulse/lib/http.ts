export class RequestError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = "RequestError";
  }
}

export async function readJson(request: Request): Promise<unknown> {
  if (!request.headers.get("content-type")?.includes("application/json")) {
    throw new RequestError("Content-Type must be application/json", 415);
  }
  const limit = 16_384;
  const reader = request.body?.getReader();
  if (!reader) throw new RequestError("Request body is required", 400);
  const chunks: Uint8Array[] = [];
  let bytes = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > limit) {
        await reader.cancel();
        throw new RequestError("Request exceeds the 16 KB limit", 413);
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const buffer = new Uint8Array(bytes);
  let offset = 0;
  for (const chunk of chunks) {
    buffer.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return JSON.parse(new TextDecoder().decode(buffer));
  } catch {
    throw new RequestError("Invalid JSON body", 400);
  }
}

const bucketState = globalThis as unknown as {
  feedbackPulseLimits?: Map<string, { count: number; expires: number }>;
};

export function checkSubmissionLimit(key: string): void {
  const buckets =
    bucketState.feedbackPulseLimits ??
    (bucketState.feedbackPulseLimits = new Map());
  const now = Date.now();
  for (const [id, bucket] of buckets)
    if (bucket.expires <= now) buckets.delete(id);
  const bucket = buckets.get(key);
  if (bucket && bucket.count >= 30)
    throw new RequestError(
      "Too many submissions. Try again in one minute.",
      429,
    );
  buckets.set(key, {
    count: (bucket?.count ?? 0) + 1,
    expires: bucket?.expires ?? now + 60_000,
  });
}
