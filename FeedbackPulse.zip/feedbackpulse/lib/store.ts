import { z } from "zod";
import { createSeed } from "./seed";
import {
  categories,
  statuses,
  Database,
  Command,
  Category,
  Sentiment,
} from "./types";
export const submissionSchema = z.object({
  workspaceId: z.string(),
  customerEmail: z.string().email().max(200),
  title: z.string().trim().min(4).max(100),
  content: z.string().trim().min(10).max(2000),
  category: z.enum(categories),
  rating: z.number().int().min(1).max(5),
});
export const commandSchema = z.discriminatedUnion("type", [
  submissionSchema.extend({ type: z.literal("submit") }),
  z.object({
    type: z.literal("status"),
    ids: z.array(z.string()).min(1).max(200),
    status: z.enum(statuses),
  }),
  z.object({ type: z.literal("triage"), workspaceId: z.string() }),
  z.object({
    type: z.literal("webhook"),
    settings: z.object({
      workspaceId: z.string(),
      provider: z.enum(["Slack", "Discord"]),
      url: z.union([z.literal(""), z.string().url().startsWith("https://")]),
      enabledEvents: z.array(
        z.enum(["feedback.created", "feedback.resolved", "feedback.negative"]),
      ),
    }),
  }),
  z.object({ type: z.literal("upgrade") }),
  z.object({
    type: z.literal("profile"),
    name: z.string().trim().min(2).max(60),
    email: z.string().email(),
  }),
  z.object({ type: z.literal("rotateKey"), workspaceId: z.string() }),
]);
export function classify(text: string): {
  category: Category;
  sentiment: Sentiment;
} {
  const t = text.toLowerCase();
  const category: Category =
    /crash|broken|freez|not working|error|bug|blocking/.test(t)
      ? "Bug"
      : /confusing|navigation|difficult|tap target|reset/.test(t)
        ? "UX Issue"
        : /would love|could we|add |integration|would be|can we|feature|dark mode/.test(
              t,
            )
          ? "Feature Request"
          : "Praise";
  const sentiment: Sentiment =
    /crash|broken|freez|not working|error|blocking|confusing|difficult|frustrat|hate/.test(
      t,
    )
      ? "Negative"
      : /love|amazing|great|excellent|fantastic|beautiful|joy|smooth/.test(t)
        ? "Positive"
        : "Neutral";
  return { category, sentiment };
}
export function applyCommand(db: Database, command: Command): Database {
  const next = structuredClone(db);
  if (
    "workspaceId" in command &&
    !next.workspaces.some((w) => w.id === command.workspaceId)
  )
    throw new Error("Workspace not found");
  switch (command.type) {
    case "submit":
      next.feedback.unshift({
        workspaceId: command.workspaceId,
        customerEmail: command.customerEmail,
        title: command.title,
        content: command.content,
        category: command.category,
        rating: command.rating,
        id: `fb_${crypto.randomUUID()}`,
        sentiment:
          command.rating >= 4
            ? "Positive"
            : command.rating <= 2
              ? "Negative"
              : "Neutral",
        status: "Inbox",
        triaged: false,
        createdAt: new Date().toISOString(),
      });
      break;
    case "status":
      for (const id of command.ids) {
        const item = next.feedback.find((f) => f.id === id);
        if (!item) throw new Error("Feedback not found");
        item.status = command.status;
      }
      break;
    case "triage":
      next.feedback = next.feedback.map((f) =>
        f.workspaceId === command.workspaceId && !f.triaged
          ? { ...f, ...classify(`${f.title} ${f.content}`), triaged: true }
          : f,
      );
      break;
    case "webhook":
      if (!next.workspaces.some((w) => w.id === command.settings.workspaceId))
        throw new Error("Workspace not found");
      next.webhooks = next.webhooks.map((w) =>
        w.workspaceId === command.settings.workspaceId ? command.settings : w,
      );
      break;
    case "upgrade":
      next.user.plan = "Pro";
      break;
    case "profile":
      next.user = { ...next.user, name: command.name, email: command.email };
      break;
    case "rotateKey":
      next.workspaces = next.workspaces.map((w) =>
        w.id === command.workspaceId
          ? {
              ...w,
              apiKey: `fp_demo_${crypto.randomUUID().replaceAll("-", "")}`,
            }
          : w,
      );
      break;
  }
  return next;
}
const globalDb = globalThis as unknown as { feedbackPulseDb?: Database };
export function getDb() {
  return globalDb.feedbackPulseDb ?? (globalDb.feedbackPulseDb = createSeed());
}
export function mutateDb(command: Command) {
  globalDb.feedbackPulseDb = applyCommand(getDb(), command);
  return globalDb.feedbackPulseDb;
}
