export const categories = [
  "Bug",
  "Feature Request",
  "UX Issue",
  "Praise",
] as const;
export const sentiments = ["Positive", "Neutral", "Negative"] as const;
export const statuses = ["Inbox", "In Progress", "Resolved"] as const;
export type Category = (typeof categories)[number];
export type Sentiment = (typeof sentiments)[number];
export type Status = (typeof statuses)[number];
export interface User {
  id: string;
  name: string;
  email: string;
  plan: "Free" | "Pro";
  role: "Owner" | "Admin";
}
export interface Workspace {
  id: string;
  name: string;
  slug: string;
  apiKey: string;
}
export interface FeedbackItem {
  id: string;
  workspaceId: string;
  customerEmail: string;
  title: string;
  content: string;
  category: Category;
  sentiment: Sentiment;
  status: Status;
  createdAt: string;
  rating: number;
  triaged: boolean;
}
export interface WebhookSettings {
  workspaceId: string;
  provider: "Slack" | "Discord";
  url: string;
  enabledEvents: string[];
}
export interface Database {
  user: User;
  workspaces: Workspace[];
  feedback: FeedbackItem[];
  webhooks: WebhookSettings[];
}
export type Command =
  | {
      type: "submit";
      workspaceId: string;
      customerEmail: string;
      title: string;
      content: string;
      category: Category;
      rating: number;
    }
  | { type: "status"; ids: string[]; status: Status }
  | { type: "triage"; workspaceId: string }
  | { type: "webhook"; settings: WebhookSettings }
  | { type: "upgrade" }
  | { type: "profile"; name: string; email: string }
  | { type: "rotateKey"; workspaceId: string };
