import test from "node:test";
import assert from "node:assert/strict";
import { readJson, checkSubmissionLimit, RequestError } from "./http";
const request = (body: string, contentType = "application/json") =>
  new Request("http://localhost/test", {
    method: "POST",
    headers: { "content-type": contentType },
    body,
  });
test("HTTP body guard parses JSON and rejects malformed or oversized input", async () => {
  assert.deepEqual(await readJson(request('{"ok":true}')), { ok: true });
  await assert.rejects(
    () => readJson(request("{broken")),
    (error) => error instanceof RequestError && error.status === 400,
  );
  await assert.rejects(
    () => readJson(request("{}", "text/plain")),
    (error) => error instanceof RequestError && error.status === 415,
  );
  await assert.rejects(
    () => readJson(request("x".repeat(17000))),
    (error) => error instanceof RequestError && error.status === 413,
  );
});
test("public submission quota bounds per-workspace requests", () => {
  const key = crypto.randomUUID();
  for (let n = 0; n < 30; n++) checkSubmissionLimit(key);
  assert.throws(
    () => checkSubmissionLimit(key),
    (error) => error instanceof RequestError && error.status === 429,
  );
  assert.doesNotThrow(() => checkSubmissionLimit(crypto.randomUUID()));
});
