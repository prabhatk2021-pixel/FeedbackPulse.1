import { test, expect } from "@playwright/test";

test("dashboard has live metrics, filters, table/kanban and workspace isolation", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Your customers. Your next big idea." }),
  ).toBeVisible();
  await page
    .getByRole("textbox", { name: "Search feedback", exact: true })
    .fill("Export to CSV");
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await page
    .getByRole("textbox", { name: "Search feedback", exact: true })
    .fill("");
  await page.getByLabel("Filter by category").selectOption("Bug");
  await expect(page.locator("tbody tr").first()).toContainText("Bug");
  await page.getByLabel("Filter by category").selectOption("");
  await page.getByRole("button", { name: "Kanban view" }).click();
  await expect(page.locator(".kanban-column")).toHaveCount(3);
  await page.getByRole("button", { name: "Table view" }).click();
  await page
    .getByRole("button", { name: /Acme Studio.*Free|Acme Studio.*Pro/ })
    .click();
  await page.getByRole("button", { name: "Acme Labs", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "The beta looks promising", exact: true }),
  ).toBeVisible();
  await expect(page.locator("tbody tr")).toHaveCount(1);
  await page.getByRole("button", { name: "Collapse sidebar" }).click();
  await expect(page.locator(".app-shell")).toHaveClass(/sidebar-collapsed/);
  expect(errors).toEqual([]);
});

test("widget validates, submits, then triage and status transitions update the inbox", async ({
  page,
}) => {
  const title = `E2E feedback ${Date.now()}`;
  await page.goto("/widget-demo");
  await page
    .getByRole("button", { name: "Send feedback", exact: true })
    .click();
  await expect(
    page.getByText("Please enter a valid email address."),
  ).toBeVisible();
  await page.getByLabel("Your email").fill("sam@example.com");
  await page.getByRole("radio", { name: "2 stars" }).click();
  await page.getByLabel("Feedback type").selectOption("Bug");
  await page.getByLabel("In a few words").fill(title);
  await page
    .getByLabel("Tell us more")
    .fill("The export is broken and blocking our monthly reporting.");
  await page
    .getByRole("button", { name: "Send feedback", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "You’re helping us get better." }),
  ).toBeVisible();
  await page
    .getByRole("link", { name: "Feedback inbox", exact: false })
    .first()
    .click();
  await page
    .getByRole("textbox", { name: "Search feedback", exact: true })
    .fill(title);
  await expect(
    page.getByRole("button", { name: title, exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: /AI Triage & Categorize/ }).click();
  await expect(
    page.getByRole("button", { name: "All caught up" }),
  ).toBeVisible();
  await page.getByLabel(`Status for ${title}`).selectOption("In Progress");
  await expect(page.getByLabel(`Status for ${title}`)).toHaveValue(
    "In Progress",
  );
  await page.getByLabel(`Status for ${title}`).selectOption("Resolved");
  await expect(page.getByLabel(`Status for ${title}`)).toHaveValue("Resolved");
  await page.getByRole("button", { name: title, exact: true }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await expect(
    page.getByText("AI triage complete (simulated)", { exact: true }),
  ).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).not.toBeVisible();
});

test("developer snippets, webhook validation and saved simulator settings", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/developers");
  await expect(page.locator(".code-block").first()).toContainText("/widget.js");
  await page.getByRole("button", { name: "React / Next.js" }).click();
  await expect(page.locator(".code-block").first()).toContainText("useEffect");
  await page
    .getByRole("textbox", { name: "Webhook endpoint" })
    .fill("http://not-secure.example/hook");
  await page.getByRole("button", { name: "Send test event" }).click();
  await expect(
    page.getByText("Enter a valid HTTPS webhook URL."),
  ).toBeVisible();
  await page
    .getByRole("textbox", { name: "Webhook endpoint" })
    .fill("https://hooks.slack.com/services/demo");
  await page.getByRole("button", { name: "Save configuration" }).click();
  await expect(
    page.getByText("Webhook configuration saved", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Send test event" }).click();
  await expect(page.getByRole("status")).toContainText("200 OK");
  await page.reload();
  await expect(
    page.getByRole("textbox", { name: "Webhook endpoint" }),
  ).toHaveValue("https://hooks.slack.com/services/demo");
  expect(errors).toEqual([]);
});

test("billing supports cancellation and a successful simulated Pro upgrade", async ({
  page,
}) => {
  await page.goto("/billing");
  await page
    .getByRole("button", { name: "Cancel checkout", exact: true })
    .click();
  await expect(page).toHaveURL(/status=cancelled/);
  await expect(
    page.getByRole("heading", { name: "Checkout cancelled" }),
  ).toBeVisible();
  await page.goto("/billing");
  const pay = page.getByRole("button", { name: "Simulate payment · $29.00" });
  if (await pay.count()) {
    await pay.click();
    await expect(page).toHaveURL(/status=success/);
    await expect(
      page.getByRole("heading", { name: "You’re officially Pro." }),
    ).toBeVisible();
  } else
    await expect(
      page.getByRole("button", { name: "Already subscribed" }),
    ).toBeDisabled();
  await page.goto("/analytics");
  await expect(
    page.getByText("of customer feedback has been resolved"),
  ).toBeVisible();
});

test("real embeddable script posts through the token-scoped endpoint", async ({
  page,
  request,
}) => {
  const db = await (await request.get("/api/store")).json();
  const title = `External embed ${Date.now()}`;
  await page.goto("/");
  await page.evaluate((key: string) => {
    const s = document.createElement("script");
    s.src = "/widget.js";
    s.dataset.key = key;
    document.body.appendChild(s);
  }, db.workspaces[0].apiKey);
  const host = page.locator("#feedbackpulse-widget");
  await host.getByRole("button", { name: "Feedback", exact: false }).click();
  await host.getByLabel("Your email").fill("external@example.com");
  await host.getByLabel("How’s your experience?").selectOption("5");
  await host.getByLabel("In a few words").fill(title);
  await host
    .getByLabel("Tell us more")
    .fill("An excellent example of embeddable feedback collection.");
  await host.getByRole("button", { name: "Send feedback →" }).click();
  await expect(host.getByText("Thanks for sharing!")).toBeVisible();
  const updated = await (await request.get("/api/store")).json();
  expect(
    updated.feedback.some((f: { title: string }) => f.title === title),
  ).toBe(true);
  const denied = await request.post("/api/feedback", {
    headers: { "X-API-Key": "invalid" },
    data: { title },
  });
  expect(denied.status()).toBe(401);
});

test("mobile layout stays within viewport and the drawer navigates", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await expect(
    page.getByRole("button", { name: "Open navigation" }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.getByRole("button", { name: "Open navigation" }).click();
  await page
    .getByRole("link", { name: "Feedback widget", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "A small widget. A big conversation." }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
});
