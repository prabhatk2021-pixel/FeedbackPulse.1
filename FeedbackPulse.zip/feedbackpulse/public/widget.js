(function () {
  "use strict";
  var script = document.currentScript;
  if (!script || !script.dataset.key) return;
  var origin = new URL(script.src).origin;
  var token = script.dataset.key;
  var hostId = script.dataset.hostId || "feedbackpulse-widget";
  if (document.getElementById(hostId)) return;
  var host = document.createElement("div");
  host.id = hostId;
  document.body.appendChild(host);
  var shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML =
    "<style>" +
    ":host{font-family:system-ui,-apple-system,sans-serif;color:#303044;font-size:14px}" +
    "*{box-sizing:border-box}button,input,select,textarea{font:inherit}button{cursor:pointer}button:focus-visible,input:focus,select:focus,textarea:focus{outline:2px solid #b2a0ef;outline-offset:2px}" +
    ".launcher{position:fixed;bottom:24px;right:24px;z-index:2147483000;background:#7461db;color:white;border:0;border-radius:40px;padding:14px 22px;box-shadow:0 4px 20px #43326330;font-size:13px;font-weight:600}" +
    ".panel{position:fixed;bottom:85px;right:24px;width:370px;max-width:calc(100vw - 32px);max-height:calc(100dvh - 110px);overflow:auto;z-index:2147483000;border:1px solid #e5e1ef;background:white;box-shadow:0 12px 50px #30305025;border-radius:16px;padding:25px;text-align:left}" +
    "[hidden]{display:none!important}h2{font-size:21px;letter-spacing:-.5px;margin:8px 0}p{font-size:12px;color:#9395a6;line-height:1.7}.close{float:right;border:0;background:none;color:#999;font-size:20px;padding:3px}" +
    "label{display:block;font-size:11px;font-weight:600;margin-top:14px;color:#656879}input,textarea,select{display:block;width:100%;border:1px solid #e2e3eb;border-radius:7px;padding:10px;margin-top:7px;font-size:12px;color:#505468;background:white}textarea{resize:vertical;min-height:80px}" +
    ".send{margin-top:18px;width:100%;background:#7461db;color:white;border:0;border-radius:8px;padding:12px;font-size:12px;font-weight:600}.send:disabled{opacity:.6}.footer{margin:16px 0 0;text-align:center;font-size:10px}.error{color:#bd526b;font-size:12px}.success{text-align:center;padding:30px 8px}.success b{font-size:20px;display:block}.success button{margin-top:10px}" +
    "@media(max-width:480px){.panel{right:16px;bottom:82px}.launcher{right:16px;bottom:18px}}" +
    '</style><button type="button" class="launcher" aria-expanded="false" aria-controls="fp-panel">✧ &nbsp; Feedback</button>' +
    '<section class="panel" id="fp-panel" role="dialog" aria-label="Send feedback" hidden>' +
    '<button type="button" class="close" aria-label="Close feedback widget">×</button>' +
    '<div class="form-view"><h2>Your voice shapes what’s next.</h2><p>Have an idea or spotted a bug? We’re all ears.</p>' +
    '<form><label>Your email<input type="email" name="customerEmail" autocomplete="email" required maxlength="200" placeholder="you@company.com"></label>' +
    '<label>How’s your experience?<select name="rating" required><option value="">Choose a rating</option><option value="5">★★★★★ — Love it!</option><option value="4">★★★★ — Pretty good</option><option value="3">★★★ — It’s okay</option><option value="2">★★ — Could be better</option><option value="1">★ — Needs work</option></select></label>' +
    '<label>Feedback type<select name="category"><option>Feature Request</option><option>Bug</option><option>UX Issue</option><option>Praise</option></select></label>' +
    '<label>In a few words<input name="title" required minlength="4" maxlength="100" placeholder="What’s on your mind?"></label>' +
    '<label>Tell us more<textarea name="content" required minlength="10" maxlength="2000" placeholder="The details make all the difference…"></textarea></label>' +
    '<p class="error" role="alert" hidden></p><button type="submit" class="send">Send feedback →</button></form>' +
    '<p class="footer">Powered by FeedbackPulse · Demo</p></div><div class="success" hidden><b>Thanks for sharing!</b><p>Your feedback is in our inbox. You’re helping us get better.</p><button type="button" class="send again">Share another thought</button></div></section>';
  var panel = shadow.querySelector(".panel");
  var launcher = shadow.querySelector(".launcher");
  var form = shadow.querySelector("form");
  var close = shadow.querySelector(".close");
  function setOpen(open) {
    panel.hidden = !open;
    launcher.setAttribute("aria-expanded", String(open));
    if (open) close.focus();
    else launcher.focus();
  }
  launcher.addEventListener("click", function () {
    setOpen(panel.hidden);
  });
  close.addEventListener("click", function () {
    setOpen(false);
  });
  shadow.addEventListener("keydown", function (event) {
    if (event.key === "Escape") setOpen(false);
  });
  shadow.querySelector(".again").addEventListener("click", function () {
    shadow.querySelector(".form-view").hidden = false;
    shadow.querySelector(".success").hidden = true;
    form.querySelector("input").focus();
  });
  form.addEventListener("submit", async function (event) {
    event.preventDefault();
    if (!form.reportValidity()) return;
    var button = form.querySelector(".send");
    var error = form.querySelector(".error");
    button.disabled = true;
    button.textContent = "Sending your thoughts…";
    error.hidden = true;
    var data = new FormData(form);
    var body = Object.fromEntries(data.entries());
    body.rating = Number(body.rating);
    try {
      var response = await fetch(origin + "/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-API-Key": token },
        body: JSON.stringify(body),
      });
      var result = await response.json();
      if (!response.ok)
        throw new Error(result.error || "Unable to send feedback.");
      form.reset();
      shadow.querySelector(".form-view").hidden = true;
      shadow.querySelector(".success").hidden = false;
      shadow.querySelector(".again").focus();
    } catch (issue) {
      error.textContent =
        issue instanceof Error
          ? issue.message
          : "Unable to connect. Please try again.";
      error.hidden = false;
    } finally {
      button.disabled = false;
      button.textContent = "Send feedback →";
    }
  });
})();
