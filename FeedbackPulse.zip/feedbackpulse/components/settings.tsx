"use client";
import { useState } from "react";
import {
  UserRound,
  Building2,
  CreditCard,
  ArrowUpRight,
  Info,
} from "lucide-react";
import { useApp } from "./provider";
import { Button } from "./ui";
export function Settings() {
  const { db, workspace, mutate, toast, openBilling } = useApp();
  const [name, setName] = useState(db.user.name);
  const [email, setEmail] = useState(db.user.email);
  const [saving, setSaving] = useState(false);
  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      await mutate({ type: "profile", name, email });
      toast("Your profile is up to date");
    } catch {
    } finally {
      setSaving(false);
    }
  }
  return (
    <>
      <div className="breadcrumb">
        Workspace <span>/</span>
        <span className="text-slate-600">Settings</span>
      </div>
      <div className="page-heading">
        <div>
          <h1>A workspace that works for you.</h1>
          <p className="mt-2">Manage the details behind your daily pulse.</p>
        </div>
      </div>
      <div className="grid items-start gap-6 lg:grid-cols-[1.3fr_1fr]">
        <section className="panel">
          <h2 className="section-heading flex items-center gap-2">
            <UserRound size={17} className="text-brand" />
            Your profile
          </h2>
          <p className="mt-2 text-xs text-slate-400">
            A familiar face behind the feedback.
          </p>
          <form onSubmit={save} className="mt-7 space-y-5">
            <label className="field-label block">
              Full name
              <input
                className="input mt-2"
                required
                minLength={2}
                maxLength={60}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </label>
            <label className="field-label block">
              Email address
              <input
                className="input mt-2"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>
            <div className="rounded-lg bg-slate-50 p-4 text-xs text-slate-500">
              Your role{" "}
              <span className="float-right font-medium text-slate-700">
                {db.user.role}
              </span>
            </div>
            <Button type="submit" variant="primary" loading={saving}>
              Save changes
            </Button>
          </form>
        </section>
        <div className="space-y-6">
          <section className="panel">
            <h2 className="section-heading flex items-center gap-2">
              <Building2 size={17} className="text-brand" />
              Workspace details
            </h2>
            <dl className="mt-6 space-y-4 text-xs">
              <div className="flex justify-between">
                <dt className="text-slate-400">Workspace</dt>
                <dd>{workspace.name}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">URL slug</dt>
                <dd>{workspace.slug}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Workspace ID</dt>
                <dd className="font-mono text-slate-500">{workspace.id}</dd>
              </div>
            </dl>
          </section>
          <section className="panel">
            <div className="flex justify-between">
              <h2 className="section-heading flex items-center gap-2">
                <CreditCard size={17} className="text-brand" />
                Your subscription
              </h2>
              <span className="badge bg-violet-50 text-brand">
                {db.user.plan}
              </span>
            </div>
            <p className="my-4 text-xs leading-6 text-slate-500">
              {db.user.plan === "Free"
                ? "You’re on the Free plan. Ready to get more from every conversation?"
                : "You’re on Pro. Advanced analytics are unlocked for your workspace."}
            </p>
            <Button onClick={openBilling}>
              {db.user.plan === "Free" ? "Explore Pro" : "Manage plan"}
              <ArrowUpRight size={14} />
            </Button>
          </section>
        </div>
      </div>
      <div className="mt-6 flex items-start gap-3 rounded-xl border border-amber-100 bg-amber-50/60 p-5">
        <Info size={18} className="mt-0.5 shrink-0 text-amber-600" />
        <div>
          <h3 className="text-xs font-semibold text-amber-800">
            A transparent demo environment
          </h3>
          <p className="mt-2 text-xs leading-6 text-amber-800/70">
            This workspace is shared across visitors to this server. Data lives
            in memory and resets on restart. There is no authentication.
            Payments, AI classification, and webhook deliveries are simulations;
            no external services are contacted. Please use sample information
            only.
          </p>
        </div>
      </div>
    </>
  );
}
