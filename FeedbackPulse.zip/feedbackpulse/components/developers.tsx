"use client";
import { useState, useEffect } from "react";
import {
  Code2,
  Copy,
  Check,
  KeyRound,
  RefreshCw,
  Send,
  Webhook,
  ShieldCheck,
  Terminal,
  Braces,
  CheckCircle2,
  Eye,
  EyeOff,
} from "lucide-react";
import { useApp } from "./provider";
import { Button, Modal } from "./ui";
import { cn } from "@/lib/utils";
export function Developers() {
  const { workspace } = useApp();
  return <DeveloperWorkspace key={workspace.id} />;
}
function DeveloperWorkspace() {
  const { workspace, db, mutate, toast } = useApp();
  const initial = db.webhooks.find((w) => w.workspaceId === workspace.id)!;
  const [tab, setTab] = useState<"script" | "react">("script");
  const [copied, setCopied] = useState("");
  const [showToken, setShowToken] = useState(false);
  const [rotate, setRotate] = useState(false);
  const [rotating, setRotating] = useState(false);
  const [provider, setProvider] = useState(initial.provider);
  const [url, setUrl] = useState(initial.url);
  const [events, setEvents] = useState(initial.enabledEvents);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [origin, setOrigin] = useState("");
  useEffect(() => setOrigin(window.location.origin), []);
  const script = `<script\n  src="${origin}/widget.js"\n  data-key="${workspace.apiKey}"\n  async\n></script>`;
  const react = `'use client';\n\nimport { useEffect } from 'react';\n\nexport function FeedbackWidget() {\n  useEffect(() => {\n    const script = document.createElement('script');\n    script.src = '${origin}/widget.js';\n    script.dataset.key = '${workspace.apiKey}';\n    script.dataset.hostId = 'feedbackpulse-widget';\n    script.async = true;\n    document.body.appendChild(script);\n    return () => {\n      script.remove();\n      document.getElementById('feedbackpulse-widget')?.remove();\n    };\n  }, []);\n  return null;\n}`;
  const example = db.feedback.find((f) => f.workspaceId === workspace.id);
  const payload =
    provider === "Slack"
      ? {
          text: `New feedback in ${workspace.name}`,
          blocks: [
            {
              type: "section",
              text: {
                type: "mrkdwn",
                text: `*${example?.title || "Your first feedback"}*\n${example?.content || "A customer shared their thoughts."}`,
              },
            },
            {
              type: "context",
              elements: [
                {
                  type: "mrkdwn",
                  text: `${example?.category || "Feature Request"} · ${example?.sentiment || "Neutral"} · ${example?.customerEmail || "customer@example.com"}`,
                },
              ],
            },
          ],
        }
      : {
          content: `New feedback in ${workspace.name}`,
          embeds: [
            {
              title: example?.title || "Your first feedback",
              description:
                example?.content || "A customer shared their thoughts.",
              color: 7627227,
              fields: [
                {
                  name: "Category",
                  value: example?.category || "Feature Request",
                  inline: true,
                },
                {
                  name: "Sentiment",
                  value: example?.sentiment || "Neutral",
                  inline: true,
                },
              ],
              footer: { text: "FeedbackPulse · feedback.created" },
            },
          ],
        };
  async function copy(text: string, id: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(id);
      toast("Copied to clipboard");
      setTimeout(() => setCopied(""), 2000);
    } catch {
      toast("Clipboard unavailable. Select and copy the code manually.", true);
    }
  }
  function validate() {
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "https:") throw new Error();
      if (!events.length) {
        setError("Choose at least one event.");
        return false;
      }
      setError("");
      return true;
    } catch {
      setError("Enter a valid HTTPS webhook URL.");
      return false;
    }
  }
  async function save() {
    if (!validate()) return;
    setSaving(true);
    try {
      await mutate({
        type: "webhook",
        settings: {
          workspaceId: workspace.id,
          provider,
          url,
          enabledEvents: events,
        },
      });
      toast("Webhook configuration saved");
    } catch {
    } finally {
      setSaving(false);
    }
  }
  async function test() {
    if (!validate()) return;
    setTesting(true);
    setResult(null);
    await new Promise((r) => setTimeout(r, 1300));
    setResult(
      `200 OK · ${provider} payload accepted by the simulator. No network request was sent.`,
    );
    setTesting(false);
    toast("Webhook simulation completed successfully");
  }
  async function rotateKey() {
    setRotating(true);
    try {
      await mutate({ type: "rotateKey", workspaceId: workspace.id });
      setRotate(false);
      toast("Workspace token rotated. Update your existing embeds.");
    } catch {
    } finally {
      setRotating(false);
    }
  }
  return (
    <>
      <div className="breadcrumb">
        Build & connect <span>/</span>
        <span className="text-slate-600">Developers</span>
      </div>
      <div className="page-heading">
        <div>
          <h1>Fits right into your workflow.</h1>
          <p className="mt-2">
            A few lines of code. A direct line to your customers.
          </p>
        </div>
        <span className="flex items-center gap-2 rounded-full border bg-white px-3 py-2 text-[11px] text-slate-500">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Developer
          sandbox
        </span>
      </div>
      <div className="grid items-start gap-6 xl:grid-cols-[1.05fr_1fr]">
        <div className="space-y-6">
          <section className="panel">
            <div className="flex items-center gap-3">
              <span className="feature-icon">
                <Code2 size={20} />
              </span>
              <div>
                <h2 className="section-heading">
                  Meet your new feedback channel
                </h2>
                <p className="mt-1 text-xs text-slate-400">
                  Drop it in. Start listening.
                </p>
              </div>
            </div>
            <div className="code-tabs">
              <button
                onClick={() => setTab("script")}
                className={cn(tab === "script" && "active")}
              >
                <Terminal size={14} /> JavaScript
              </button>
              <button
                onClick={() => setTab("react")}
                className={cn(tab === "react" && "active")}
              >
                <Braces size={14} /> React / Next.js
              </button>
            </div>
            <div className="code-block">
              <div className="code-header">
                <span>
                  {tab === "script" ? "index.html" : "FeedbackWidget.tsx"}
                </span>
                <button
                  aria-label="Copy embed code"
                  onClick={() =>
                    copy(tab === "script" ? script : react, "code")
                  }
                >
                  {copied === "code" ? <Check size={13} /> : <Copy size={13} />}{" "}
                  {copied === "code" ? "Copied" : "Copy code"}
                </button>
              </div>
              <pre>
                <code>{tab === "script" ? script : react}</code>
              </pre>
            </div>
            <p className="mt-4 text-xs leading-6 text-slate-500">
              {tab === "script" ? (
                <>
                  Add this before the closing{" "}
                  <code className="inline-code">&lt;/body&gt;</code> tag. The
                  widget sends validated feedback directly to this workspace.
                </>
              ) : (
                <>
                  Render{" "}
                  <code className="inline-code">&lt;FeedbackWidget /&gt;</code>{" "}
                  once in your app layout. The client component loads the widget
                  and removes it on unmount.
                </>
              )}
            </p>
            <div className="mt-4 rounded-lg bg-slate-50 p-3 text-[11px] leading-5 text-slate-500">
              Use your deployed application URL in production. Preview URLs only
              work while this server is running. The token is public and
              submission-only; it is not an admin credential.
            </div>
          </section>
          <section className="panel">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <KeyRound size={17} className="text-brand" />
                <h2 className="section-heading">Workspace API token</h2>
              </div>
              <span className="badge bg-slate-100 text-slate-500">PUBLIC</span>
            </div>
            <p className="mt-2 text-xs text-slate-400">
              Identifies submissions for {workspace.name}.
            </p>
            <div className="mt-5 flex items-center gap-2 rounded-lg border bg-slate-50 px-3 py-3">
              <code className="min-w-0 flex-1 truncate text-[11px] text-slate-600">
                {showToken ? workspace.apiKey : "fp_demo_••••••••••••••••"}
              </code>
              <button
                onClick={() => setShowToken(!showToken)}
                aria-label={showToken ? "Hide token" : "Show token"}
                className="text-slate-400"
              >
                {showToken ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
              <button
                onClick={() => copy(workspace.apiKey, "token")}
                aria-label="Copy API token"
                className="text-slate-400"
              >
                {copied === "token" ? <Check size={14} /> : <Copy size={14} />}
              </button>
            </div>
            <button
              className="mt-4 flex items-center gap-2 text-xs text-slate-500"
              onClick={() => setRotate(true)}
            >
              <RefreshCw size={12} /> Rotate token
            </button>
          </section>
        </div>
        <section className="panel">
          <div className="flex items-center gap-3">
            <span className="feature-icon">
              <Webhook size={21} />
            </span>
            <div>
              <h2 className="section-heading">Keep your team in the loop</h2>
              <p className="mt-1 text-xs text-slate-400">
                Webhook configuration & delivery simulator
              </p>
            </div>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-3">
            {(["Slack", "Discord"] as const).map((p) => (
              <button
                key={p}
                onClick={() => {
                  setProvider(p);
                  setResult(null);
                }}
                className={cn(
                  "flex items-center justify-center gap-2 rounded-lg border py-3 text-sm font-medium",
                  provider === p
                    ? "border-violet-300 bg-violet-50 text-brand"
                    : "text-slate-500",
                )}
              >
                <span className="text-lg font-bold">
                  {p === "Slack" ? "#" : "◉"}
                </span>
                {p}
                {provider === p && <Check size={14} />}
              </button>
            ))}
          </div>
          <label className="field-label mt-5 block">
            Webhook endpoint
            <input
              type="url"
              className="input mt-2"
              value={url}
              onChange={(e) => {
                setUrl(e.target.value);
                setError("");
                setResult(null);
              }}
              placeholder={
                provider === "Slack"
                  ? "https://hooks.slack.com/services/…"
                  : "https://discord.com/api/webhooks/…"
              }
              aria-invalid={!!error}
              aria-describedby="webhook-error"
            />
          </label>
          {error && (
            <p id="webhook-error" className="mt-2 text-xs text-rose-500">
              {error}
            </p>
          )}
          <fieldset className="mt-5">
            <legend className="field-label mb-3">Send notifications for</legend>
            <div className="flex flex-wrap gap-x-4 gap-y-3">
              {[
                ["feedback.created", "New feedback"],
                ["feedback.resolved", "Resolved feedback"],
                ["feedback.negative", "Negative sentiment"],
              ].map(([value, label]) => (
                <label
                  key={value}
                  className="flex items-center gap-2 text-[11px] text-slate-600"
                >
                  <input
                    type="checkbox"
                    checked={events.includes(value)}
                    onChange={(e) => {
                      setEvents((s) =>
                        e.target.checked
                          ? [...s, value]
                          : s.filter((v) => v !== value),
                      );
                      setResult(null);
                    }}
                  />
                  {label}
                </label>
              ))}
            </div>
          </fieldset>
          <div className="mt-6 flex items-center justify-between">
            <label className="field-label">Live payload preview</label>
            <button
              onClick={() => copy(JSON.stringify(payload, null, 2), "payload")}
              className="flex items-center gap-1 text-[10px] text-slate-400"
            >
              {copied === "payload" ? <Check size={12} /> : <Copy size={12} />}{" "}
              Copy JSON
            </button>
          </div>
          <div className="code-block mt-3">
            <div className="code-header">
              <span>
                <span className="mr-2 text-emerald-400">POST</span>{" "}
                application/json
              </span>
              <span>feedback.created</span>
            </div>
            <pre className="max-h-[250px]">
              <code>{JSON.stringify(payload, null, 2)}</code>
            </pre>
          </div>
          <div className="mt-5 flex gap-3">
            <Button onClick={save} loading={saving} className="flex-1">
              Save configuration
            </Button>
            <Button
              variant="primary"
              onClick={test}
              loading={testing}
              className="flex-1"
            >
              {!testing && <Send size={13} />}{" "}
              {testing ? "Simulating…" : "Send test event"}
            </Button>
          </div>
          {result && (
            <div
              role="status"
              className="mt-4 flex gap-2 rounded-lg bg-emerald-50 p-3 text-[11px] leading-5 text-emerald-700"
            >
              <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
              {result}
            </div>
          )}
          <p className="mt-4 flex gap-2 text-[10px] leading-5 text-slate-400">
            <ShieldCheck size={14} className="mt-0.5 shrink-0" />
            Sandbox mode: tests validate your configuration and simulate
            delivery. Your endpoint is never contacted. Event selections are
            stored, not automatically dispatched.
          </p>
        </section>
      </div>
      <Modal
        open={rotate}
        onClose={() => setRotate(false)}
        title="Rotate this workspace token?"
      >
        <p className="text-sm leading-6 text-slate-500">
          Your existing token will stop accepting submissions immediately. Copy
          the new embed snippet into any sites using this workspace.
        </p>
        <div className="mt-6 flex justify-end gap-3">
          <Button onClick={() => setRotate(false)}>Keep current token</Button>
          <Button variant="primary" loading={rotating} onClick={rotateKey}>
            Rotate token
          </Button>
        </div>
      </Modal>
    </>
  );
}
