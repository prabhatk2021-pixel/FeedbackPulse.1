"use client";
import { useState } from "react";
import {
  Star,
  Send,
  Check,
  ArrowRight,
  MessageSquare,
  Activity,
} from "lucide-react";
import { categories, Category } from "@/lib/types";
import { useApp } from "./provider";
import { Button } from "./ui";
export function FeedbackForm({
  onSubmitted,
  compact = false,
}: {
  onSubmitted?: () => void;
  compact?: boolean;
}) {
  const { workspace, mutate, toast } = useApp();
  const [email, setEmail] = useState("");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<Category>("Feature Request");
  const [rating, setRating] = useState(0);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const errors = {
    email: !/^\S+@\S+\.\S+$/.test(email)
      ? "Please enter a valid email address."
      : "",
    title:
      title.trim().length < 4 ? "Add a title of at least 4 characters." : "",
    content:
      content.trim().length < 10
        ? "Tell us a little more (at least 10 characters)."
        : "",
    rating: rating === 0 ? "Choose a rating from 1 to 5." : "",
  };
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setTouched({ email: true, title: true, content: true, rating: true });
    if (Object.values(errors).some(Boolean)) return;
    setBusy(true);
    try {
      await new Promise((r) => setTimeout(r, 650));
      await mutate({
        type: "submit",
        workspaceId: workspace.id,
        customerEmail: email.trim(),
        title: title.trim(),
        content: content.trim(),
        category,
        rating,
      });
      toast("Feedback received. Thanks for helping us get better!");
      setDone(true);
      onSubmitted?.();
    } catch {
    } finally {
      setBusy(false);
    }
  }
  const fieldError = (name: keyof typeof errors) =>
    touched[name] && errors[name] ? (
      <p id={`${name}-error`} className="mt-1 text-[11px] text-rose-500">
        {errors[name]}
      </p>
    ) : null;
  if (done)
    return (
      <div className="py-14 text-center">
        <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 text-emerald-500">
          <Check size={30} />
        </div>
        <h3 className="text-xl font-semibold">You’re helping us get better.</h3>
        <p className="mx-auto mt-3 max-w-xs text-sm leading-6 text-slate-500">
          Your feedback is in our inbox. Thanks for taking a moment to share
          your thoughts.
        </p>
        <Button
          className="mt-6"
          onClick={() => {
            setDone(false);
            setTitle("");
            setContent("");
            setRating(0);
            setTouched({});
          }}
        >
          Share another thought <ArrowRight size={14} />
        </Button>
      </div>
    );
  return (
    <form onSubmit={submit} noValidate className="feedback-form">
      {!compact && (
        <>
          <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-violet-100 text-brand">
            <MessageSquare size={21} />
          </div>
          <h2 className="text-xl font-semibold tracking-tight">
            Your voice shapes what’s next.
          </h2>
          <p className="mt-2 text-xs leading-5 text-slate-500">
            Have an idea, spotted a bug, or just want to say hi? We’re all ears.
          </p>
        </>
      )}
      <fieldset className="mt-5">
        <legend className="field-label">How’s your experience so far?</legend>
        <div
          className="mt-2 flex gap-2"
          role="radiogroup"
          aria-label="Experience rating"
          onKeyDown={(event) => {
            const keys = [
              "ArrowRight",
              "ArrowUp",
              "ArrowLeft",
              "ArrowDown",
              "Home",
              "End",
            ];
            if (!keys.includes(event.key)) return;
            event.preventDefault();
            const current = rating || 1;
            const next =
              event.key === "Home"
                ? 1
                : event.key === "End"
                  ? 5
                  : ["ArrowRight", "ArrowUp"].includes(event.key)
                    ? (current % 5) + 1
                    : ((current + 3) % 5) + 1;
            setRating(next);
            setTouched((t) => ({ ...t, rating: true }));
            event.currentTarget.querySelectorAll("button")[next - 1]?.focus();
          }}
        >
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              role="radio"
              aria-checked={rating === n}
              tabIndex={rating === n || (!rating && n === 1) ? 0 : -1}
              type="button"
              aria-label={`${n} star${n > 1 ? "s" : ""}`}
              onClick={() => {
                setRating(n);
                setTouched((t) => ({ ...t, rating: true }));
              }}
              className={`rating-star ${rating >= n ? "selected" : ""}`}
            >
              <Star size={23} fill={rating >= n ? "currentColor" : "none"} />
            </button>
          ))}
          {rating > 0 && (
            <span className="ml-2 self-center text-xs text-slate-400">
              {
                [
                  "",
                  "Needs work",
                  "Could be better",
                  "It’s okay",
                  "Pretty good",
                  "Love it!",
                ][rating]
              }
            </span>
          )}
        </div>
        {fieldError("rating")}
      </fieldset>
      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <label className="field-label">
          Your email
          <input
            type="email"
            value={email}
            maxLength={200}
            onChange={(e) => setEmail(e.target.value)}
            onBlur={() => setTouched((t) => ({ ...t, email: true }))}
            aria-invalid={!!(touched.email && errors.email)}
            aria-describedby="email-error"
            className="input mt-2"
            placeholder="you@company.com"
          />
          {fieldError("email")}
        </label>
        <label className="field-label">
          Feedback type
          <select
            className="input mt-2"
            value={category}
            onChange={(e) => setCategory(e.target.value as Category)}
          >
            {categories.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
      </div>
      <label className="field-label mt-4 block">
        In a few words
        <input
          className="input mt-2"
          value={title}
          maxLength={100}
          placeholder="What’s on your mind?"
          onChange={(e) => setTitle(e.target.value)}
          onBlur={() => setTouched((t) => ({ ...t, title: true }))}
          aria-invalid={!!(touched.title && errors.title)}
          aria-describedby="title-error"
        />
        {fieldError("title")}
      </label>
      <label className="field-label mt-4 block">
        Tell us more
        <textarea
          className="input mt-2 min-h-[100px] resize-y"
          placeholder="The details make all the difference…"
          value={content}
          maxLength={2000}
          onChange={(e) => setContent(e.target.value)}
          onBlur={() => setTouched((t) => ({ ...t, content: true }))}
          aria-invalid={!!(touched.content && errors.content)}
          aria-describedby="content-error"
        />
        {fieldError("content")}
      </label>
      <div className="mt-1 text-right text-[10px] text-slate-400">
        {content.length} / 2,000
      </div>
      <Button
        variant="primary"
        className="mt-3 w-full"
        type="submit"
        loading={busy}
      >
        {busy ? "Sending your thoughts…" : "Send feedback"}
        {!busy && <Send size={14} />}
      </Button>
      <div className="mt-4 flex items-center justify-center gap-1 text-[10px] text-slate-400">
        Powered by <Activity size={11} className="ml-1 text-brand" />
        <span className="font-medium text-slate-500">FeedbackPulse</span>
      </div>
    </form>
  );
}
