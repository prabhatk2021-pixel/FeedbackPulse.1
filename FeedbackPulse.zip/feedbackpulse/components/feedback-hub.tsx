"use client";
import { useMemo, useState, useEffect } from "react";
import {
  Search,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  List,
  Columns3,
  ArrowUpDown,
  ArrowUpRight,
  X,
  Sparkles,
  Calendar,
  Mail,
} from "lucide-react";
import {
  FeedbackItem,
  categories,
  statuses,
  sentiments,
  Status,
} from "@/lib/types";
import { useApp } from "./provider";
import {
  Button,
  CategoryBadge,
  SentimentBadge,
  StatusBadge,
  Modal,
  EmptyState,
} from "./ui";
import { cn, initials, timeAgo } from "@/lib/utils";
export function FeedbackHub({
  items,
  full = false,
}: {
  items: FeedbackItem[];
  full?: boolean;
}) {
  const { db, search, setSearch, mutate, toast, now } = useApp();
  const [tab, setTab] = useState("All feedback");
  const [category, setCategory] = useState("");
  const [sentiment, setSentiment] = useState("");
  const [status, setStatus] = useState("");
  const [view, setView] = useState<"list" | "board">("list");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<string[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [sort, setSort] = useState<"new" | "old">("new");
  const [saving, setSaving] = useState(false);
  const [filters, setFilters] = useState(true);
  const pageSize = full ? 8 : 5;
  const filtered = useMemo(
    () =>
      items
        .filter(
          (f) =>
            (!search ||
              `${f.title} ${f.content} ${f.customerEmail}`
                .toLowerCase()
                .includes(search.toLowerCase())) &&
            (!category || f.category === category) &&
            (!sentiment || f.sentiment === sentiment) &&
            (!status || f.status === status) &&
            (tab === "All feedback" || f.status === tab),
        )
        .sort((a, b) =>
          sort === "new"
            ? +new Date(b.createdAt) - +new Date(a.createdAt)
            : +new Date(a.createdAt) - +new Date(b.createdAt),
        ),
    [items, search, category, sentiment, status, tab, sort],
  );
  useEffect(() => {
    setPage(1);
    setSelected([]);
  }, [search, category, sentiment, status, tab, items.length]);
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, pages);
  const shown = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);
  const detail = db.feedback.find((f) => f.id === active);
  async function update(ids: string[], value: Status) {
    setSaving(true);
    try {
      await mutate({ type: "status", ids, status: value });
      toast(
        `${ids.length === 1 ? "Feedback" : `${ids.length} items`} moved to ${value.toLowerCase()}`,
      );
      setSelected([]);
    } catch {
    } finally {
      setSaving(false);
    }
  }
  function clear() {
    setSearch("");
    setCategory("");
    setSentiment("");
    setStatus("");
    setTab("All feedback");
  }
  return (
    <section className="feedback-panel">
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 pt-5">
        <div className="flex items-center gap-2.5">
          <h2 className="section-heading">
            {full ? "Your feedback inbox" : "Recent feedback"}
          </h2>
          <span className="count-pill">{items.length}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden items-center gap-1.5 text-[10px] text-slate-400 sm:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Live
            updates
          </span>
          <div className="view-toggle">
            <button
              className={cn(view === "list" && "selected")}
              onClick={() => setView("list")}
              title="Table view"
              aria-label="Table view"
              aria-pressed={view === "list"}
            >
              <List size={15} />
            </button>
            <button
              className={cn(view === "board" && "selected")}
              onClick={() => setView("board")}
              title="Kanban view"
              aria-label="Kanban view"
              aria-pressed={view === "board"}
            >
              <Columns3 size={15} />
            </button>
          </div>
        </div>
      </div>
      <div className="feedback-tabs" role="group" aria-label="Feedback status">
        {["All feedback", ...statuses].map((t) => (
          <button
            key={t}
            aria-pressed={t === tab}
            onClick={() => {
              setTab(t);
              setStatus("");
            }}
            className={cn(t === tab && "active")}
          >
            {t}
            <span>
              {t === "All feedback"
                ? items.length
                : items.filter((f) => f.status === t).length}
            </span>
          </button>
        ))}
      </div>
      <div className="filter-bar">
        <div className="feedback-search">
          <Search size={14} />
          <input
            aria-label="Search feedback"
            placeholder="Search feedback…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          {search && (
            <button aria-label="Clear search" onClick={() => setSearch("")}>
              <X size={13} />
            </button>
          )}
        </div>
        {filters && (
          <div className="flex flex-wrap gap-2">
            <select
              className="filter-select"
              aria-label="Filter by category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="">All categories</option>
              {categories.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
            <select
              className="filter-select"
              aria-label="Filter by sentiment"
              value={sentiment}
              onChange={(e) => setSentiment(e.target.value)}
            >
              <option value="">All sentiments</option>
              {sentiments.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
            <select
              className="filter-select"
              aria-label="Filter by status"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setTab("All feedback");
              }}
            >
              <option value="">All statuses</option>
              {statuses.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </div>
        )}
        <button
          className="ml-auto flex h-8 items-center gap-1.5 rounded-md border px-2.5 text-[11px] text-slate-500"
          onClick={() => setFilters(!filters)}
          aria-expanded={filters}
        >
          <SlidersHorizontal size={12} />
          <span className="hidden xl:inline">Filters</span>
        </button>
      </div>
      {selected.length > 0 && (
        <div className="flex flex-wrap items-center gap-3 border-t bg-violet-50 px-5 py-2 text-xs text-brand">
          <span>{selected.length} selected</span>
          <select
            aria-label="Set status for selected feedback"
            className="filter-select"
            value=""
            disabled={saving}
            onChange={(e) => update(selected, e.target.value as Status)}
          >
            <option value="" disabled>
              Move selected to…
            </option>
            {statuses.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
          <button onClick={() => setSelected([])} className="ml-auto">
            Clear selection
          </button>
        </div>
      )}
      {filtered.length === 0 ? (
        <EmptyState
          title="A quiet corner of your inbox"
          description="No feedback matches these filters. Try broadening your search."
          action={<Button onClick={clear}>Clear filters</Button>}
        />
      ) : view === "list" ? (
        <div className="table-scroll">
          <table className="feedback-table">
            <thead>
              <tr>
                <th className="w-10">
                  <input
                    type="checkbox"
                    aria-label="Select visible feedback"
                    checked={
                      shown.length > 0 &&
                      shown.every((f) => selected.includes(f.id))
                    }
                    onChange={(e) =>
                      setSelected(
                        e.target.checked ? shown.map((f) => f.id) : [],
                      )
                    }
                  />
                </th>
                <th className="feedback-title-cell">Feedback</th>
                <th>Category</th>
                <th>Sentiment</th>
                <th>Status</th>
                <th>
                  <button
                    className="flex items-center gap-1"
                    onClick={() => setSort(sort === "new" ? "old" : "new")}
                    aria-label="Toggle date sort"
                  >
                    Date <ArrowUpDown size={11} />
                  </button>
                </th>
                <th className="w-6" />
              </tr>
            </thead>
            <tbody>
              {shown.map((f, i) => (
                <tr
                  key={f.id}
                  className={cn(selected.includes(f.id) && "row-selected")}
                >
                  <td>
                    <input
                      type="checkbox"
                      aria-label={`Select ${f.title}`}
                      checked={selected.includes(f.id)}
                      onChange={(e) =>
                        setSelected((s) =>
                          e.target.checked
                            ? [...s, f.id]
                            : s.filter((id) => id !== f.id),
                        )
                      }
                    />
                  </td>
                  <td>
                    <button
                      className="feedback-title-button"
                      aria-label={f.title}
                      onClick={() => setActive(f.id)}
                    >
                      <span className={`customer-avatar avatar-${i % 5}`}>
                        {initials(f.customerEmail)}
                      </span>
                      <span className="min-w-0 text-left">
                        <span className="block truncate text-[11px] font-medium text-slate-700">
                          {f.title}
                        </span>
                        <span className="mt-1 block truncate text-[10px] text-slate-400">
                          {f.customerEmail}
                        </span>
                      </span>
                    </button>
                  </td>
                  <td>
                    <CategoryBadge value={f.category} />
                  </td>
                  <td>
                    <SentimentBadge value={f.sentiment} />
                  </td>
                  <td>
                    <select
                      disabled={saving}
                      aria-label={`Status for ${f.title}`}
                      value={f.status}
                      onChange={(e) => update([f.id], e.target.value as Status)}
                      className={cn(
                        "status-select",
                        f.status === "Resolved"
                          ? "resolved"
                          : f.status === "In Progress"
                            ? "progress"
                            : "inbox",
                      )}
                    >
                      {statuses.map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                  <td className="whitespace-nowrap text-[10px] text-slate-400">
                    {timeAgo(f.createdAt, now)}
                  </td>
                  <td>
                    <button
                      className="text-slate-300 hover:text-brand"
                      aria-label={`View ${f.title}`}
                      onClick={() => setActive(f.id)}
                    >
                      <ArrowUpRight size={15} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="kanban-grid">
          {statuses.map((s) => (
            <div key={s} className="kanban-column">
              <div className="mb-4 flex items-center justify-between">
                <StatusBadge value={s} />
                <span className="text-xs text-slate-400">
                  {filtered.filter((f) => f.status === s).length}
                </span>
              </div>
              {filtered
                .filter((f) => f.status === s)
                .map((f) => (
                  <article key={f.id} className="kanban-card">
                    <div className="mb-3 flex justify-between">
                      <CategoryBadge value={f.category} />
                      <span className="text-[10px] text-slate-400">
                        {timeAgo(f.createdAt, now)}
                      </span>
                    </div>
                    <button
                      className="text-left text-sm font-medium leading-5"
                      onClick={() => setActive(f.id)}
                    >
                      {f.title}
                    </button>
                    <p className="my-2 line-clamp-2 text-xs leading-5 text-slate-400">
                      {f.content}
                    </p>
                    <div className="my-4">
                      <SentimentBadge value={f.sentiment} />
                    </div>
                    <select
                      className="input text-xs"
                      value={f.status}
                      aria-label={`Move ${f.title}`}
                      disabled={saving}
                      onChange={(e) => update([f.id], e.target.value as Status)}
                    >
                      {statuses.map((st) => (
                        <option key={st}>{st}</option>
                      ))}
                    </select>
                  </article>
                ))}
              {!filtered.some((f) => f.status === s) && (
                <p className="py-10 text-center text-xs text-slate-400">
                  Nothing here yet
                </p>
              )}
            </div>
          ))}
        </div>
      )}
      <div className="table-footer">
        <p>
          {filtered.length === 0
            ? "No feedback to show"
            : view === "board"
              ? `${filtered.length} feedback items`
              : `Showing ${(safePage - 1) * pageSize + 1}–${Math.min(safePage * pageSize, filtered.length)} of ${filtered.length} feedback items`}
        </p>
        {view === "list" && (
          <div className="flex items-center gap-2">
            <button
              className="pagination-button"
              aria-label="Previous page"
              disabled={safePage === 1}
              onClick={() => setPage(safePage - 1)}
            >
              <ChevronLeft size={14} />
            </button>
            {Array.from({ length: Math.min(pages, 5) }, (_, i) => i + 1).map(
              (p) => (
                <button
                  key={p}
                  className={cn(
                    "pagination-button",
                    p === safePage && "active",
                  )}
                  onClick={() => setPage(p)}
                  aria-label={`Page ${p}`}
                  aria-current={p === safePage ? "page" : undefined}
                >
                  {p}
                </button>
              ),
            )}
            <button
              className="pagination-button"
              aria-label="Next page"
              disabled={safePage === pages}
              onClick={() => setPage(safePage + 1)}
            >
              <ChevronRight size={14} />
            </button>
          </div>
        )}
      </div>
      <Modal
        open={!!detail}
        onClose={() => setActive(null)}
        title="Feedback details"
      >
        {detail && (
          <>
            <div className="flex gap-2">
              <CategoryBadge value={detail.category} />
              <SentimentBadge value={detail.sentiment} />
            </div>
            <h3 className="my-5 text-xl font-semibold leading-7">
              {detail.title}
            </h3>
            <p className="whitespace-pre-wrap text-sm leading-7 text-slate-600">
              {detail.content}
            </p>
            <div className="my-6 space-y-3 rounded-lg bg-slate-50 p-4 text-xs text-slate-500">
              <p className="flex items-center gap-2">
                <Mail size={14} />
                {detail.customerEmail}
              </p>
              <p className="flex items-center gap-2">
                <Calendar size={14} />
                {new Date(detail.createdAt).toLocaleString()}
              </p>
              <p>
                Experience rating: {"★".repeat(detail.rating)}
                {"☆".repeat(5 - detail.rating)} · {detail.rating}/5
              </p>
              <p className="flex items-center gap-2">
                <Sparkles size={14} />
                {detail.triaged
                  ? "AI triage complete (simulated)"
                  : "Waiting for AI triage"}
              </p>
            </div>
            <label className="field-label">
              Workflow status
              <select
                value={detail.status}
                disabled={saving}
                onChange={(e) => update([detail.id], e.target.value as Status)}
                className="input mt-2"
              >
                {statuses.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </label>
          </>
        )}
      </Modal>
    </section>
  );
}
