"use client";
import { useState } from "react";
import Link from "next/link";
import {
  Monitor,
  Smartphone,
  ArrowUpRight,
  MessageSquare,
  X,
  Code2,
  MousePointer2,
  Check,
  LayoutTemplate,
  LockKeyhole,
  ChevronRight,
} from "lucide-react";
import { useApp } from "./provider";
import { FeedbackForm } from "./feedback-form";
import { cn } from "@/lib/utils";
export function WidgetDemo() {
  const { workspace } = useApp();
  const [device, setDevice] = useState<"desktop" | "mobile">("desktop");
  const [open, setOpen] = useState(true);
  const [color, setColor] = useState("#7461db");
  return (
    <>
      <div className="breadcrumb">
        Build & connect <span>/</span>
        <span className="text-slate-600">Feedback widget</span>
      </div>
      <div className="page-heading">
        <div>
          <h1>A small widget. A big conversation.</h1>
          <p className="mt-2">
            Give your customers a voice, right inside your product.
          </p>
        </div>
        <Link href="/developers" className="btn btn-primary">
          <Code2 size={15} /> Get embed code <ArrowUpRight size={14} />
        </Link>
      </div>
      <div className="widget-layout">
        <aside className="panel h-fit">
          <div className="mb-5 flex items-center gap-2">
            <LayoutTemplate size={16} className="text-brand" />
            <h2 className="section-heading">Make it feel like you</h2>
          </div>
          <p className="text-xs leading-6 text-slate-500">
            This is a live widget, not a screenshot. Try submitting feedback to{" "}
            <strong className="font-medium text-slate-700">
              {workspace.name}
            </strong>
            .
          </p>
          <div className="my-6 border-t" />
          <label className="field-label">Preview device</label>
          <div className="mt-3 flex gap-2">
            {(["desktop", "mobile"] as const).map((d) => (
              <button
                key={d}
                onClick={() => setDevice(d)}
                className={cn(
                  "flex flex-1 items-center justify-center gap-2 rounded-lg border py-3 text-xs capitalize",
                  device === d
                    ? "border-violet-300 bg-violet-50 text-brand"
                    : "text-slate-500",
                )}
              >
                {d === "desktop" ? (
                  <Monitor size={16} />
                ) : (
                  <Smartphone size={16} />
                )}{" "}
                {d}
              </button>
            ))}
          </div>
          <p className="field-label mt-6">
            Accent color{" "}
            <span className="ml-1 text-[10px] font-normal text-slate-400">
              preview only
            </span>
          </p>
          <div className="mt-3 flex gap-3">
            {["#7461db", "#4b83cb", "#299884", "#dc9864", "#333846"].map(
              (c) => (
                <button
                  key={c}
                  aria-label={`Set accent ${c}`}
                  aria-pressed={color === c}
                  style={{ background: c }}
                  className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-full text-white",
                    color === c &&
                      "outline outline-2 outline-offset-2 outline-slate-300",
                  )}
                  onClick={() => setColor(c)}
                >
                  {color === c && <Check size={15} />}
                </button>
              ),
            )}
          </div>
          <div className="my-6 border-t" />
          <div className="flex gap-3 rounded-lg bg-violet-50 p-4">
            <MousePointer2 className="mt-0.5 shrink-0 text-brand" size={16} />
            <p className="text-xs leading-5 text-violet-800">
              Go ahead, try it out. Your submission appears instantly in the
              feedback inbox.
            </p>
          </div>
          <Link
            href="/feedback"
            className="mt-5 flex items-center gap-1 text-xs font-medium text-brand"
          >
            Open your feedback inbox <ChevronRight size={14} />
          </Link>
        </aside>
        <div
          className={cn(
            "widget-browser",
            device === "mobile" && "mobile-preview",
          )}
        >
          <div className="browser-chrome">
            <div className="flex gap-1.5">
              <i />
              <i />
              <i />
            </div>
            <span className="flex items-center gap-1.5">
              <LockKeyhole size={10} /> app.{workspace.slug}.com
            </span>
            <span className="text-[9px] uppercase tracking-widest">
              Live preview
            </span>
          </div>
          <div className="demo-site">
            <div className="demo-site-nav">
              <span className="font-bold tracking-tight">
                acme<span className="text-brand">.</span>
              </span>
              <div className="flex gap-4 text-[10px] text-slate-400">
                <span>Product</span>
                <span>Resources</span>
                <span className="rounded bg-slate-100 px-2 py-1">
                  Your workspace
                </span>
              </div>
            </div>
            <div className="demo-site-content">
              <span className="text-[9px] font-semibold uppercase tracking-[2px] text-brand">
                A little space to do big things
              </span>
              <h2>
                Make room
                <br />
                for your best work.
              </h2>
              <p>Your ideas. Your team. All in one place.</p>
              <div className="demo-skeleton">
                <div />
                <div />
                <div />
              </div>
            </div>
            {open && (
              <div
                className="widget-popup"
                style={{ "--widget-color": color } as React.CSSProperties}
              >
                <button
                  aria-label="Close feedback widget"
                  className="absolute right-4 top-4 text-slate-400 hover:text-slate-700"
                  onClick={() => setOpen(false)}
                >
                  <X size={17} />
                </button>
                <FeedbackForm key={workspace.id} />
              </div>
            )}
            <button
              onClick={() => setOpen(!open)}
              style={{ background: color }}
              className="widget-launcher"
              aria-expanded={open}
            >
              {open ? <X size={17} /> : <MessageSquare size={17} />} Feedback
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
