"use client";
import { useState } from "react";
import {
  MessageSquare,
  Smile,
  Frown,
  ListTodo,
  ArrowUpRight,
  Sparkles,
  ArrowRight,
  LockKeyhole,
} from "lucide-react";
import { FeedbackItem } from "@/lib/types";
import { useApp } from "./provider";
import { Button } from "./ui";
export function Stats({
  items,
  days = 30,
}: {
  items: FeedbackItem[];
  days?: number;
}) {
  const { now } = useApp();
  const total = items.length;
  const histogram = (predicate: (f: FeedbackItem) => boolean) => {
    const counts = Array.from({ length: 12 }, () => 0);
    for (const item of items.filter(predicate)) {
      const index = Math.min(
        11,
        Math.max(
          0,
          Math.floor(
            ((new Date(item.createdAt).getTime() - (now - days * 86400000)) /
              (days * 86400000)) *
              12,
          ),
        ),
      );
      counts[index]++;
    }
    const maximum = Math.max(1, ...counts);
    return counts.map((n) => (n ? 8 + (n / maximum) * 40 : 2));
  };
  const positive = items.filter((f) => f.sentiment === "Positive").length;
  const negative = items.filter((f) => f.sentiment === "Negative").length;
  const pending = items.filter((f) => f.status !== "Resolved").length;
  const metrics = [
    {
      title: "Total feedback",
      value: String(total),
      icon: MessageSquare,
      color: "violet",
      note: "Every voice, in one place",
      bars: histogram(() => true),
    },
    {
      title: "Positive sentiment",
      value: `${total ? Math.round((positive / total) * 100) : 0}`,
      suffix: "%",
      icon: Smile,
      color: "green",
      note: `${positive} happy customer${positive === 1 ? "" : "s"}`,
      bars: histogram((f) => f.sentiment === "Positive"),
    },
    {
      title: "Negative sentiment",
      value: `${total ? Math.round((negative / total) * 100) : 0}`,
      suffix: "%",
      icon: Frown,
      color: "orange",
      note: `${negative} opportunities to improve`,
      bars: histogram((f) => f.sentiment === "Negative"),
    },
    {
      title: "Pending action items",
      value: String(pending),
      icon: ListTodo,
      color: "blue",
      note: `${items.filter((f) => f.status === "Inbox").length} in inbox · ${items.filter((f) => f.status === "In Progress").length} in progress`,
      bars: histogram((f) => f.status !== "Resolved"),
    },
  ];
  return (
    <div className="stats-grid">
      {metrics.map((m) => (
        <div key={m.title} className={`stat-card stat-${m.color}`}>
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-slate-500">{m.title}</p>
            <span className="stat-icon">
              <m.icon size={16} strokeWidth={1.6} />
            </span>
          </div>
          <div className="mt-3 flex items-end justify-between">
            <p className="text-[32px] font-semibold leading-none tracking-[-1.2px]">
              {m.value}
              <span className="ml-0.5 text-[23px] font-medium text-slate-400">
                {m.suffix}
              </span>
            </p>
            <div className="spark-bars" aria-hidden="true">
              {m.bars.map((v, i) => (
                <span
                  key={i}
                  style={{
                    height: total ? v * 0.66 : 2,
                    opacity: 0.2 + i * 0.055,
                  }}
                />
              ))}
            </div>
          </div>
          <p className="mt-4 flex items-center gap-1.5 text-[10px] text-slate-500">
            <span className="stat-dot" />
            {m.note}
          </p>
        </div>
      ))}
    </div>
  );
}
export function Trend({
  items,
  days,
}: {
  items: FeedbackItem[];
  days: number;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const segments = 7;
  const { now } = useApp();
  const series = ["Positive", "Neutral", "Negative"] as const;
  const colors = ["#9b88e5", "#bdc3d2", "#edb38d"];
  const buckets = Array.from({ length: segments }, (_, i) => {
    const start = now - days * 86400000 + (i / segments) * days * 86400000;
    const end = now - days * 86400000 + ((i + 1) / segments) * days * 86400000;
    const list = items.filter((f) => {
      const t = new Date(f.createdAt).getTime();
      return t >= start && t <= end;
    });
    return {
      date: new Date(start),
      counts: series.map((s) => list.filter((f) => f.sentiment === s).length),
    };
  });
  const max = Math.max(
    3,
    Math.ceil(Math.max(...buckets.flatMap((b) => b.counts)) / 3) * 3,
  );
  const x = (i: number) => 48 + i * 88;
  const y = (v: number) => 145 - (v / max) * 112;
  return (
    <section className="panel trend-panel">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="section-heading">Feedback activity</h2>
          <p className="mt-1 text-[11px] text-slate-400">
            A pulse on what your customers are saying
          </p>
        </div>
        <div className="flex items-center gap-3">
          {series.map((s, i) => (
            <span
              key={s}
              className="hidden items-center gap-1.5 text-[10px] text-slate-500 sm:flex"
            >
              <span
                className="h-1.5 w-1.5 rounded-full"
                style={{ background: colors[i] }}
              />
              {s}
            </span>
          ))}
        </div>
      </div>
      <div className="relative mt-3">
        <svg
          viewBox="0 0 615 179"
          className="w-full overflow-visible"
          role="img"
          aria-label={`Feedback sentiment counts across the last ${days} days`}
        >
          <defs>
            {colors.map((c, i) => (
              <linearGradient
                key={c}
                id={`fill-${i}`}
                x1="0"
                y1="0"
                x2="0"
                y2="1"
              >
                <stop offset="0%" stopColor={c} stopOpacity=".18" />
                <stop offset="100%" stopColor={c} stopOpacity=".01" />
              </linearGradient>
            ))}
          </defs>
          {[0, 1, 2, 3].map((i) => (
            <g key={i}>
              <line
                x1="34"
                x2="599"
                y1={145 - i * 37.3}
                y2={145 - i * 37.3}
                stroke="#edf0f4"
                strokeDasharray="3 4"
              />
              <text
                x="16"
                y={149 - i * 37.3}
                textAnchor="end"
                fontSize="9"
                fill="#a0a5b3"
              >
                {Math.round((i * max) / 3)}
              </text>
            </g>
          ))}
          {series.map((s, j) => {
            const points = buckets
              .map((b, i) => `${x(i)},${y(b.counts[j])}`)
              .join(" ");
            return (
              <g key={s}>
                <polygon
                  points={`48,145 ${points} 576,145`}
                  fill={`url(#fill-${j})`}
                />
                <polyline
                  points={points}
                  fill="none"
                  stroke={colors[j]}
                  strokeWidth="2"
                  strokeLinejoin="round"
                />
                {buckets.map((b, i) => (
                  <circle
                    key={i}
                    cx={x(i)}
                    cy={y(b.counts[j])}
                    r={hover === i ? 4 : 2.5}
                    fill="white"
                    stroke={colors[j]}
                    strokeWidth="1.5"
                  />
                ))}
              </g>
            );
          })}
          {buckets.map((b, i) => (
            <g key={i}>
              <text
                x={x(i)}
                y="173"
                textAnchor="middle"
                fontSize="9"
                fill="#9399a8"
              >
                {b.date.toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  timeZone: "UTC",
                })}
              </text>
              <rect
                x={x(i) - 30}
                y="15"
                width="60"
                height="139"
                fill="transparent"
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(null)}
              >
                <title>{`${b.date.toLocaleDateString("en-US", { timeZone: "UTC" })}: ${b.counts.map((n, j) => `${n} ${series[j]}`).join(", ")}`}</title>
              </rect>
            </g>
          ))}
        </svg>
        {hover !== null && (
          <div className="pointer-events-none absolute right-3 top-0 rounded-lg border bg-white px-3 py-2 text-[10px] shadow-sm">
            {buckets[hover].counts.map((n, i) => (
              <span key={i} className="mr-2" style={{ color: colors[i] }}>
                {series[i]}: {n}
              </span>
            ))}
          </div>
        )}
      </div>
      <div className="mt-1 flex items-center gap-1.5 text-[10px] text-slate-400">
        <span className="h-1 w-1 rounded-full bg-brand" /> Live workspace data{" "}
        <span className="mx-1">·</span> Last {days} days
      </div>
    </section>
  );
}
export function Insight({ items }: { items: FeedbackItem[] }) {
  const { openBilling, db } = useApp();
  const [expanded, setExpanded] = useState(false);
  const positive = items.filter((f) => f.sentiment === "Positive").length;
  const requests = items.filter((f) => f.category === "Feature Request").length;
  const negative = items.filter((f) => f.sentiment === "Negative").length;
  return (
    <section className="insight-card">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-2 text-xs font-medium text-violet-100">
          <Sparkles size={16} /> The bigger picture
        </span>
        <span
          className="insight-ai"
          title="Simulated insight, calculated from your workspace data"
        >
          AI INSIGHT
        </span>
      </div>
      <div className="insight-orbit" aria-hidden="true">
        <span />
        <span />
        <Sparkles size={19} />
      </div>
      <h2 className="relative mt-6 max-w-[240px] text-xl font-medium leading-[1.35] tracking-[-.4px]">
        {positive > negative
          ? "Your customers are feeling good."
          : "Every voice is an opportunity."}
      </h2>
      <p className="relative mt-3 max-w-[295px] text-[11px] leading-[1.85] text-[#c1b9de]">
        {items.length
          ? `${Math.round((positive / items.length) * 100)}% of feedback is positive. ${requests ? `${requests} feature requests show your customers are invested in what comes next.` : "Keep listening to uncover your next opportunity."}`
          : "Collect your first piece of feedback to start understanding your customers."}
      </p>
      <button
        className="relative mt-6 flex items-center gap-2 text-[11px] font-medium text-white"
        onClick={() =>
          db.user.plan === "Pro" ? setExpanded(!expanded) : openBilling()
        }
      >
        {db.user.plan === "Pro"
          ? "Explore your insights"
          : "Unlock deeper insights"}
        <ArrowRight size={13} />
        {db.user.plan === "Free" && (
          <span className="ml-1 rounded bg-white/10 px-1.5 py-0.5 text-[9px] text-violet-200">
            PRO
          </span>
        )}
      </button>
      {expanded && (
        <p className="relative mt-4 border-t border-white/10 pt-3 text-xs leading-5 text-violet-200">
          Focus next on {negative} negative reports and review {requests}{" "}
          feature requests with your product team. This summary is generated
          from workspace counts, not a live LLM.
        </p>
      )}
      <div className="absolute bottom-0 right-0 h-32 w-32 rounded-full bg-violet-500/10 blur-3xl" />
    </section>
  );
}
export function Breakdown({ items }: { items: FeedbackItem[] }) {
  const { db, openBilling } = useApp();
  return (
    <div className="grid gap-5 md:grid-cols-2">
      <section className="panel">
        <h2 className="section-heading">Feedback by category</h2>
        <p className="mb-6 mt-1 text-xs text-slate-400">
          Understand what is driving the conversation
        </p>
        {["Praise", "Feature Request", "Bug", "UX Issue"].map((c, i) => {
          const count = items.filter((f) => f.category === c).length;
          return (
            <div key={c} className="mb-5">
              <div className="mb-2 flex justify-between text-xs">
                <span>{c}</span>
                <span className="text-slate-400">{count} items</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100">
                <div
                  className="h-2 rounded-full"
                  style={{
                    width: `${items.length ? (count / items.length) * 100 : 0}%`,
                    background: ["#9a85de", "#9ba9dc", "#e8aa98", "#e4bd7e"][i],
                  }}
                />
              </div>
            </div>
          );
        })}
      </section>
      <section className="panel">
        <div className="flex justify-between">
          <h2 className="section-heading">Resolution insights</h2>
          <span className="badge bg-violet-50 text-brand">PRO</span>
        </div>
        {db.user.plan === "Free" ? (
          <div className="py-10 text-center">
            <LockKeyhole className="mx-auto mb-4 text-brand" size={26} />
            <h3 className="text-sm font-semibold">
              From listening to taking action
            </h3>
            <p className="mx-auto my-3 max-w-xs text-xs leading-5 text-slate-500">
              See your team’s resolution rate and understand how much feedback
              is moving forward.
            </p>
            <Button onClick={openBilling} variant="primary">
              Explore Pro <ArrowUpRight size={14} />
            </Button>
          </div>
        ) : (
          <div className="py-8">
            <p className="text-5xl font-semibold text-brand">
              {items.length
                ? Math.round(
                    (items.filter((f) => f.status === "Resolved").length /
                      items.length) *
                      100,
                  )
                : 0}
              %
            </p>
            <p className="mt-3 text-sm text-slate-500">
              of customer feedback has been resolved
            </p>
            <div className="mt-8 grid grid-cols-3 gap-3">
              {["Inbox", "In Progress", "Resolved"].map((s) => (
                <div key={s}>
                  <p className="text-2xl font-semibold">
                    {items.filter((f) => f.status === s).length}
                  </p>
                  <p className="mt-1 text-xs text-slate-400">{s}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
