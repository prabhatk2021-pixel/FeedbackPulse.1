"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState, ReactNode } from "react";
import {
  Activity,
  LayoutDashboard,
  MessageSquare,
  ChartNoAxesCombined,
  Code2,
  PanelsTopLeft,
  Settings2,
  ChevronDown,
  ChevronsUpDown,
  Search,
  Bell,
  PanelLeftClose,
  PanelLeftOpen,
  ArrowUpRight,
  Sparkles,
  HelpCircle,
  Check,
  Menu,
  Command,
  CreditCard,
} from "lucide-react";
import { useApp } from "./provider";
import { cn, initials } from "@/lib/utils";
import { Billing } from "./billing";
import { Modal, Button } from "./ui";
const nav = [
  { href: "/", label: "Overview", icon: LayoutDashboard },
  { href: "/feedback", label: "Feedback inbox", icon: MessageSquare },
  { href: "/analytics", label: "Analytics", icon: ChartNoAxesCombined },
];
const tools = [
  { href: "/widget-demo", label: "Feedback widget", icon: PanelsTopLeft },
  { href: "/developers", label: "Developers", icon: Code2 },
  { href: "/settings", label: "Settings", icon: Settings2 },
];
export function Shell({ children }: { children: ReactNode }) {
  const {
    db,
    workspace,
    setWorkspace,
    search,
    setSearch,
    openBilling,
    online,
  } = useApp();
  const pathname = usePathname();
  const router = useRouter();
  const [collapsed, setCollapsed] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [menu, setMenu] = useState<string | null>(null);
  const [help, setHelp] = useState(false);
  const [read, setRead] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const count = db.feedback.filter(
    (f) => f.workspaceId === workspace.id && f.status === "Inbox",
  ).length;
  useEffect(() => {
    function close(e: MouseEvent) {
      if (!menuRef.current?.contains(e.target as Node)) setMenu(null);
    }
    function key(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setMenu(null);
        setMobile(false);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        searchRef.current?.focus();
      }
    }
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", key);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", key);
    };
  }, []);
  useEffect(() => {
    setMobile(false);
    setMenu(null);
  }, [pathname]);
  const item = (n: (typeof nav)[number]) => (
    <Link
      title={collapsed ? n.label : undefined}
      key={n.href}
      href={n.href}
      className={cn(
        "nav-item",
        pathname === n.href && "active",
        collapsed && "justify-center px-0",
      )}
      aria-current={pathname === n.href ? "page" : undefined}
    >
      <n.icon size={18} strokeWidth={1.7} />
      {!collapsed && (
        <>
          <span>{n.label}</span>
          {n.href === "/feedback" && (
            <span className="ml-auto rounded-md bg-white/10 px-1.5 py-0.5 text-[10px]">
              {count}
            </span>
          )}
        </>
      )}
    </Link>
  );
  return (
    <div className={cn("app-shell", collapsed && "sidebar-collapsed")}>
      {mobile && (
        <button
          className="fixed inset-0 z-30 bg-slate-950/40 lg:hidden"
          aria-label="Close navigation"
          onClick={() => setMobile(false)}
        />
      )}
      <aside className={cn("sidebar", mobile && "mobile-open")}>
        <Link
          href="/"
          className={cn("brand", collapsed && "justify-center px-0")}
        >
          <span className="brand-mark">
            <Activity size={22} strokeWidth={2.4} />
          </span>
          {!collapsed && (
            <span>
              Feedback<span className="font-normal text-[#b9b5ce]">Pulse</span>
              <span className="ml-1 text-brand">.</span>
            </span>
          )}
        </Link>
        <div className="flex flex-1 flex-col overflow-y-auto px-4 pt-6">
          <div className="nav-label">{collapsed ? "•••" : "WORKSPACE"}</div>
          <nav aria-label="Workspace navigation" className="space-y-1">
            {nav.map(item)}
          </nav>
          <div className="nav-label mt-8">
            {collapsed ? "•••" : "BUILD & CONNECT"}
          </div>
          <nav aria-label="Tools" className="space-y-1">
            {tools.map(item)}
          </nav>
          <div className="mt-auto pt-12">
            {!collapsed && (
              <div className="upgrade-card">
                <div className="mb-3 flex items-center gap-2 text-sm font-medium">
                  <Sparkles size={17} className="text-[#b6a1ff]" />
                  {db.user.plan === "Pro"
                    ? "You’re on Pulse Pro"
                    : "Good feedback. Great growth."}
                </div>
                <p className="text-xs leading-5 text-[#a6a3b7]">
                  {db.user.plan === "Pro"
                    ? "More insights. More possibilities. All your Pro features are unlocked."
                    : "Unlock deeper insights and put your feedback on autopilot."}
                </p>
                <button
                  onClick={openBilling}
                  className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg border border-white/10 bg-white/5 py-2.5 text-xs font-medium text-white"
                >
                  {db.user.plan === "Pro"
                    ? "Manage subscription"
                    : "Explore Pro"}
                  <ArrowUpRight size={14} />
                </button>
              </div>
            )}
            <button
              aria-label="Help & getting started"
              title="Help & getting started"
              onClick={() => setHelp(true)}
              className="nav-item mt-4 w-full"
            >
              <HelpCircle size={18} />
              {!collapsed && (
                <>
                  <span>Help & getting started</span>
                  <ArrowUpRight size={14} className="ml-auto" />
                </>
              )}
            </button>
          </div>
        </div>
        <div className="sidebar-bottom">
          <span className="flex items-center gap-2 text-[11px] text-[#a7a6b6]">
            {!collapsed && (
              <>
                <span
                  className={cn(
                    "h-1.5 w-1.5 rounded-full",
                    online ? "bg-emerald-400" : "bg-amber-400",
                  )}
                />
                {online ? "All systems operational" : "Reconnecting…"}
              </>
            )}
          </span>
          <button
            className="text-[#9693aa] hover:text-white"
            title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? (
              <PanelLeftOpen size={17} />
            ) : (
              <PanelLeftClose size={17} />
            )}
          </button>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar" ref={menuRef}>
          <button
            className="icon-button lg:hidden"
            aria-label="Open navigation"
            onClick={() => setMobile(true)}
          >
            <Menu size={21} />
          </button>
          <div className="relative">
            <button
              className="workspace-button"
              onClick={() => setMenu(menu === "workspace" ? null : "workspace")}
              aria-expanded={menu === "workspace"}
            >
              <span className="workspace-avatar">
                {workspace.name === "Acme Studio" ? "A" : "L"}
                <span />
              </span>
              <span className="hidden text-sm font-semibold sm:inline">
                {workspace.name}
              </span>
              <span className="hidden rounded border px-1.5 py-0.5 text-[10px] font-medium text-slate-500 sm:inline">
                {db.user.plan}
              </span>
              <ChevronsUpDown size={14} className="ml-2 text-slate-400" />
            </button>
            {menu === "workspace" && (
              <div className="dropdown left-0 w-64">
                <p className="menu-label">Your workspaces</p>
                {db.workspaces.map((w) => (
                  <button
                    key={w.id}
                    onClick={() => {
                      setWorkspace(w.id);
                      setMenu(null);
                    }}
                  >
                    {w.name}
                    {w.id === workspace.id && <Check size={15} />}
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="ml-auto flex items-center gap-3 sm:gap-5">
            <div className="header-search">
              <Search size={15} />
              <input
                ref={searchRef}
                aria-label="Search all feedback"
                placeholder="Search anything…"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  if (pathname !== "/" && pathname !== "/feedback")
                    router.push("/feedback");
                }}
              />
              <kbd>
                <Command size={10} /> K
              </kbd>
            </div>
            <div className="relative">
              <button
                className="notification-button"
                title="Notifications"
                aria-label="Notifications"
                aria-expanded={menu === "notifications"}
                onClick={() => {
                  setMenu(menu === "notifications" ? null : "notifications");
                  setRead(true);
                }}
              >
                <Bell size={19} />
                {!read && <span />}
              </button>
              {menu === "notifications" && (
                <div className="dropdown right-0 w-80">
                  <p className="menu-label">Your pulse, at a glance</p>
                  <div className="px-3 py-3 text-sm">
                    <div className="font-medium">
                      {count} items need your attention
                    </div>
                    <p className="mt-1 text-xs leading-5 text-slate-500">
                      Your team’s next great idea could be in the inbox.
                    </p>
                    <Link
                      href="/feedback"
                      className="mt-3 inline-block text-xs font-medium text-brand"
                    >
                      View feedback →
                    </Link>
                  </div>
                  <div className="border-t px-3 py-3 text-xs text-slate-500">
                    Widget submissions sync automatically.
                  </div>
                </div>
              )}
            </div>
            <span className="h-6 w-px bg-slate-200" />
            <div className="relative">
              <button
                className="flex items-center gap-2"
                onClick={() => setMenu(menu === "user" ? null : "user")}
                aria-label="User menu"
                aria-expanded={menu === "user"}
              >
                <span className="user-avatar">{initials(db.user.name)}</span>
                <ChevronDown size={13} className="text-slate-400" />
              </button>
              {menu === "user" && (
                <div className="dropdown right-0 w-60">
                  <div className="px-3 py-2">
                    <p className="text-sm font-semibold">{db.user.name}</p>
                    <p className="mt-1 text-xs text-slate-500">
                      {db.user.email} · {db.user.role}
                    </p>
                  </div>
                  <button onClick={() => router.push("/settings")}>
                    <span className="flex items-center gap-2">
                      <Settings2 size={15} />
                      Account settings
                    </span>
                  </button>
                  <button
                    onClick={() => {
                      setMenu(null);
                      openBilling();
                    }}
                  >
                    <span className="flex items-center gap-2">
                      <CreditCard size={15} />
                      Plans & billing
                    </span>
                  </button>
                  <div className="border-t px-3 pt-3 pb-1 text-[11px] text-slate-400">
                    Demo account · no sign-in required
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>
        <main className="page-content">
          {children}
          <footer className="page-footer">
            <span>Made for teams that listen.</span>
            <span className="flex items-center gap-1.5">
              <Activity size={12} /> FeedbackPulse{" "}
              <span className="mx-1 text-slate-300">/</span> Demo workspace
            </span>
          </footer>
        </main>
      </div>
      <Billing />
      <Modal
        open={help}
        onClose={() => setHelp(false)}
        title="A little feedback goes a long way"
      >
        <div className="space-y-5 text-sm text-slate-600">
          <p>
            Welcome to your interactive FeedbackPulse workspace. Here’s where to
            start:
          </p>
          {[
            [
              "01",
              "Listen",
              "Open the feedback widget and submit a message. It will appear in your inbox immediately.",
            ],
            [
              "02",
              "Understand",
              "Run AI Triage to simulate sentiment and category classification, then update a feedback status.",
            ],
            [
              "03",
              "Connect",
              "Generate your embed code and test a Slack or Discord webhook in Developers.",
            ],
          ].map(([n, t, d]) => (
            <div key={n} className="flex gap-4">
              <span className="font-mono text-brand">{n}</span>
              <div>
                <h3 className="mb-1 font-semibold text-slate-800">{t}</h3>
                <p>{d}</p>
              </div>
            </div>
          ))}
          <div className="rounded-lg bg-violet-50 p-4 text-xs leading-5 text-violet-800">
            This is a shared, in-memory demo. AI, webhook delivery, and payments
            are simulated. Data resets when the server restarts. Don’t enter
            sensitive information.
          </div>
          <Button variant="primary" onClick={() => setHelp(false)}>
            Let’s get started
          </Button>
        </div>
      </Modal>
    </div>
  );
}
