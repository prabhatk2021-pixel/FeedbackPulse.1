"use client";
import { useEffect, useRef, ReactNode, ButtonHTMLAttributes } from "react";
import {
  X,
  Loader2,
  Check,
  Circle,
  Clock3,
  CircleCheck,
  Bug,
  Lightbulb,
  MousePointer2,
  Heart,
} from "lucide-react";
import { cn } from "@/lib/utils";
export function Button({
  children,
  className,
  variant = "default",
  loading,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "default" | "primary" | "ghost";
  loading?: boolean;
}) {
  return (
    <button
      {...props}
      disabled={loading || props.disabled}
      className={cn(
        "btn",
        variant === "primary"
          ? "btn-primary"
          : variant === "ghost"
            ? "btn-ghost"
            : "btn-default",
        className,
      )}
    >
      {loading && <Loader2 size={15} className="animate-spin" />}
      {children}
    </button>
  );
}
export function Modal({
  open,
  onClose,
  title,
  children,
  wide = false,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = ref.current;
    if (open) {
      dialog?.showModal();
      document.body.style.overflow = "hidden";
    } else dialog?.close();
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);
  return (
    <dialog
      ref={ref}
      onCancel={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className={cn("modal", wide && "modal-wide")}
      aria-label={title}
    >
      <div className="flex items-center justify-between border-b px-6 py-5">
        <h2 className="text-lg font-semibold">{title}</h2>
        <button
          onClick={onClose}
          className="icon-button"
          aria-label="Close dialog"
        >
          <X size={19} />
        </button>
      </div>
      <div className="p-6">{children}</div>
    </dialog>
  );
}
const categoryIcons = {
  Bug,
  "Feature Request": Lightbulb,
  "UX Issue": MousePointer2,
  Praise: Heart,
};
export function CategoryBadge({ value }: { value: string }) {
  const Icon = categoryIcons[value as keyof typeof categoryIcons] || Lightbulb;
  return (
    <span
      className={cn(
        "badge category",
        value === "Bug"
          ? "bug"
          : value === "Praise"
            ? "praise"
            : value === "UX Issue"
              ? "ux"
              : "feature",
      )}
    >
      <Icon size={12} />
      {value}
    </span>
  );
}
export function SentimentBadge({ value }: { value: string }) {
  return (
    <span className={cn("badge sentiment", value.toLowerCase())}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {value}
    </span>
  );
}
export function StatusBadge({ value }: { value: string }) {
  const Icon =
    value === "Resolved"
      ? CircleCheck
      : value === "In Progress"
        ? Clock3
        : Circle;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 text-xs",
        value === "Resolved"
          ? "text-emerald-600"
          : value === "In Progress"
            ? "text-amber-600"
            : "text-slate-500",
      )}
    >
      <Icon size={13} />
      {value}
    </span>
  );
}
export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="py-16 px-6 text-center">
      <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-violet-50 text-brand">
        <Check size={24} />
      </div>
      <h3 className="font-semibold">{title}</h3>
      <p className="mt-2 mb-5 text-sm text-slate-500">{description}</p>
      {action}
    </div>
  );
}
