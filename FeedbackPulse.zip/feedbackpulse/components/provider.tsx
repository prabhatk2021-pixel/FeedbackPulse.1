"use client";
import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
  useRef,
} from "react";
import { CheckCircle2, AlertCircle, X } from "lucide-react";
import { Command, Database, Workspace } from "@/lib/types";
interface AppContext {
  db: Database;
  workspace: Workspace;
  setWorkspace: (id: string) => void;
  mutate: (command: Command) => Promise<void>;
  toast: (message: string, error?: boolean) => void;
  openBilling: () => void;
  billingOpen: boolean;
  closeBilling: () => void;
  search: string;
  setSearch: (v: string) => void;
  online: boolean;
  now: number;
}
const Context = createContext<AppContext | null>(null);
export function Provider({
  children,
  initialDb,
  initialNow,
}: {
  children: ReactNode;
  initialDb: Database;
  initialNow: number;
}) {
  const [db, setDb] = useState(initialDb);
  const [now, setNow] = useState(initialNow);
  const [workspaceId, setWorkspaceId] = useState("ws_acme");
  const [search, setSearch] = useState("");
  const [billingOpen, setBillingOpen] = useState(false);
  const [online, setOnline] = useState(true);
  const [toasts, setToasts] = useState<
    { id: number; message: string; error: boolean }[]
  >([]);
  const mutationCount = useRef(0);
  const refreshVersion = useRef(0);
  const toast = useCallback((message: string, error = false) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, message, error }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4500);
  }, []);
  useEffect(() => {
    const saved = localStorage.getItem("fp-workspace");
    if (saved) setWorkspaceId(saved);
    let alive = true;
    async function refresh() {
      setNow(Date.now());
      const version = refreshVersion.current;
      try {
        const response = await fetch("/api/store", { cache: "no-store" });
        if (!response.ok) throw new Error();
        const data: Database = await response.json();
        if (
          alive &&
          mutationCount.current === 0 &&
          version === refreshVersion.current
        ) {
          setDb(data);
          setNow(Date.now());
          setOnline(true);
        }
      } catch {
        if (alive) setOnline(false);
      }
    }
    refresh();
    const timer = setInterval(refresh, 15000);
    window.addEventListener("focus", refresh);
    return () => {
      alive = false;
      clearInterval(timer);
      window.removeEventListener("focus", refresh);
    };
  }, []);
  const queue = useRef<Promise<void>>(Promise.resolve());
  const mutate = useCallback(
    (command: Command) => {
      const operation = queue.current
        .catch(() => {})
        .then(async () => {
          mutationCount.current++;
          refreshVersion.current++;
          try {
            const response = await fetch("/api/store", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(command),
            });
            const data = await response.json();
            if (!response.ok)
              throw new Error(data.error || "Could not save changes");
            setDb(data);
            setNow(Date.now());
            setOnline(true);
          } catch (error) {
            toast(
              error instanceof Error ? error.message : "Something went wrong",
              true,
            );
            throw error;
          } finally {
            mutationCount.current--;
          }
        });
      queue.current = operation;
      return operation;
    },
    [toast],
  );
  const workspace =
    db.workspaces.find((w) => w.id === workspaceId) || db.workspaces[0];
  return (
    <Context.Provider
      value={{
        db,
        workspace,
        setWorkspace: (id) => {
          setWorkspaceId(id);
          localStorage.setItem("fp-workspace", id);
          setSearch("");
        },
        mutate,
        toast,
        billingOpen,
        openBilling: () => setBillingOpen(true),
        closeBilling: () => setBillingOpen(false),
        search,
        setSearch,
        online,
        now,
      }}
    >
      {children}
      <div
        className="fixed bottom-6 right-6 z-[100] flex max-w-sm flex-col gap-3"
        aria-live="polite"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-xl"
          >
            {t.error ? (
              <AlertCircle size={19} className="shrink-0 text-rose-500" />
            ) : (
              <CheckCircle2 size={19} className="shrink-0 text-emerald-500" />
            )}
            <span>{t.message}</span>
            <button
              aria-label="Dismiss notification"
              onClick={() => setToasts((s) => s.filter((x) => x.id !== t.id))}
            >
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
    </Context.Provider>
  );
}
export function useApp() {
  const context = useContext(Context);
  if (!context) throw new Error("Provider is required");
  return context;
}
