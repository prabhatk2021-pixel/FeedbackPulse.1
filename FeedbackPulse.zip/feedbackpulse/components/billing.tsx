"use client";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { useState, Suspense } from "react";
import {
  Check,
  ArrowRight,
  ShieldCheck,
  CreditCard,
  CircleCheck,
  CircleX,
  ArrowLeft,
  Activity,
} from "lucide-react";
import { useApp } from "./provider";
import { Modal, Button } from "./ui";
export function Billing() {
  const { db, billingOpen, closeBilling } = useApp();
  const router = useRouter();
  return (
    <Modal
      open={billingOpen}
      onClose={closeBilling}
      title="Make every voice count"
      wide
    >
      <p className="mb-7 text-sm text-slate-500">
        A plan for wherever your product is headed. No real payment required.
      </p>
      <div className="grid gap-5 sm:grid-cols-2">
        {[
          {
            name: "Free",
            price: "0",
            subtitle: "Start listening to your customers.",
            features: [
              "One production workspace",
              "100 feedback items / month",
              "Basic sentiment overview",
              "Embeddable feedback widget",
            ],
          },
          {
            name: "Pro",
            price: "29",
            subtitle: "Turn feedback into your next big thing.",
            features: [
              "Unlimited feedback & workspaces",
              "Advanced sentiment analytics",
              "AI-powered triage & automation",
              "Slack & Discord integrations",
              "Priority support",
            ],
          },
        ].map((plan) => (
          <div
            key={plan.name}
            className={`relative rounded-xl border p-6 ${plan.name === "Pro" ? "border-brand bg-violet-50/50" : "border-slate-200"}`}
          >
            {plan.name === "Pro" && (
              <span className="absolute -top-3 right-4 rounded-full bg-brand px-3 py-1 text-[10px] font-semibold text-white">
                BUILT FOR GROWTH
              </span>
            )}
            <h3 className="text-lg font-semibold">{plan.name}</h3>
            <p className="mt-1 text-xs text-slate-500">{plan.subtitle}</p>
            <p className="my-6">
              <span className="text-4xl font-semibold tracking-tight">
                ${plan.price}
              </span>
              <span className="text-sm text-slate-500"> / month</span>
            </p>
            <Button
              className="w-full"
              variant={plan.name === "Pro" ? "primary" : "default"}
              disabled={db.user.plan === plan.name || plan.name === "Free"}
              onClick={() => {
                closeBilling();
                router.push("/billing");
              }}
            >
              {db.user.plan === plan.name
                ? "Your current plan"
                : plan.name === "Free"
                  ? "Starter plan"
                  : "Upgrade to Pro"}
              {plan.name === "Pro" && db.user.plan !== "Pro" && (
                <ArrowRight size={15} />
              )}
            </Button>
            <ul className="mt-6 space-y-3">
              {plan.features.map((f) => (
                <li
                  key={f}
                  className="flex items-center gap-2 text-xs text-slate-600"
                >
                  <Check size={14} className="shrink-0 text-brand" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <p className="mt-5 text-center text-xs text-slate-400">
        Demo tier descriptions are illustrative. Core workflows remain available
        to explore.
      </p>
    </Modal>
  );
}
function CheckoutContent() {
  const { db, mutate, toast } = useApp();
  const router = useRouter();
  const params = useSearchParams();
  const status = params.get("status");
  const [busy, setBusy] = useState(false);
  async function pay() {
    setBusy(true);
    try {
      await new Promise((r) => setTimeout(r, 1600));
      await mutate({ type: "upgrade" });
      toast("Welcome to Pro. Your next chapter starts here.");
      router.replace("/billing?status=success");
    } catch {
      setBusy(false);
    }
  }
  if (status === "success" || status === "cancelled")
    return (
      <div className="mx-auto my-16 max-w-lg rounded-2xl border bg-white p-10 text-center">
        {status === "success" ? (
          <CircleCheck size={48} className="mx-auto mb-5 text-emerald-500" />
        ) : (
          <CircleX size={48} className="mx-auto mb-5 text-slate-400" />
        )}
        <h1 className="text-2xl font-semibold">
          {status === "success"
            ? "You’re officially Pro."
            : "Checkout cancelled"}
        </h1>
        <p className="my-4 text-sm leading-6 text-slate-500">
          {status === "success"
            ? "Your workspace now has access to advanced insights. Your feedback deserves the full picture."
            : "No payment was made and your plan hasn’t changed. Your feedback is right where you left it."}
        </p>
        <Link className="btn btn-primary mt-3" href="/">
          Back to overview <ArrowRight size={16} />
        </Link>
      </div>
    );
  return (
    <div className="mx-auto max-w-3xl py-7">
      <Link
        href="/"
        className="mb-7 inline-flex items-center gap-2 text-sm text-slate-500"
      >
        <ArrowLeft size={15} /> Back to workspace
      </Link>
      <div className="overflow-hidden rounded-2xl border bg-white shadow-card">
        <div className="grid md:grid-cols-2">
          <div className="bg-[#211e35] p-8 text-white">
            <span className="mb-10 flex items-center gap-2 text-sm">
              <Activity size={20} className="text-violet-300" /> FeedbackPulse
            </span>
            <p className="text-sm text-violet-200">Subscribe to Pulse Pro</p>
            <p className="mt-4 text-4xl font-semibold">
              $29
              <span className="text-sm font-normal text-slate-400">
                {" "}
                / month
              </span>
            </p>
            <div className="my-8 border-t border-white/10" />
            <div className="flex justify-between text-sm">
              <span>Pro subscription</span>
              <span>$29.00</span>
            </div>
            <p className="mt-2 text-xs text-slate-400">
              Billed monthly · Cancel anytime
            </p>
            <div className="mt-8 flex justify-between border-t border-white/10 pt-5 text-sm font-semibold">
              <span>Total due today</span>
              <span>$29.00</span>
            </div>
          </div>
          <div className="p-8">
            <span className="badge bg-amber-50 text-amber-700">
              TEST CHECKOUT
            </span>
            <h1 className="mt-5 text-xl font-semibold">
              One step closer to better insights
            </h1>
            <p className="mt-3 text-sm leading-6 text-slate-500">
              This simulates a Stripe Checkout session. No payment details are
              collected and you won’t be charged.
            </p>
            <div className="my-6 flex items-center gap-3 rounded-lg border bg-slate-50 p-4">
              <CreditCard size={23} className="text-slate-400" />
              <div>
                <p className="text-sm font-medium">Demo payment method</p>
                <p className="mt-1 text-xs text-slate-400">
                  •••• 4242 · Always succeeds
                </p>
              </div>
            </div>
            <Button
              variant="primary"
              className="w-full"
              loading={busy}
              disabled={db.user.plan === "Pro"}
              onClick={pay}
            >
              {db.user.plan === "Pro"
                ? "Already subscribed"
                : busy
                  ? "Processing checkout…"
                  : "Simulate payment · $29.00"}
            </Button>
            <Button
              variant="ghost"
              className="mt-2 w-full"
              disabled={busy}
              onClick={() => router.replace("/billing?status=cancelled")}
            >
              Cancel checkout
            </Button>
            <p className="mt-5 flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
              <ShieldCheck size={13} /> Safe simulation. Zero real charges.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
export function Checkout() {
  return (
    <Suspense
      fallback={<p className="p-10 text-slate-500">Loading checkout…</p>}
    >
      <CheckoutContent />
    </Suspense>
  );
}
