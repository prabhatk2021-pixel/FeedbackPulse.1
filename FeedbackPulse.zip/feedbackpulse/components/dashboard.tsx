"use client";
import { useState } from "react";
import { CalendarDays, Download, Plus, Sparkles } from "lucide-react";
import { useApp } from "./provider";
import { Stats, Trend, Insight, Breakdown } from "./analytics";
import { FeedbackHub } from "./feedback-hub";
import { FeedbackForm } from "./feedback-form";
import { Button, Modal } from "./ui";
export function Dashboard({
  mode = "overview",
}: {
  mode?: "overview" | "feedback" | "analytics";
}) {
  const { db, workspace, mutate, toast, now } = useApp();
  const [days, setDays] = useState(30);
  const [addOpen, setAddOpen] = useState(false);
  const [triaging, setTriaging] = useState(false);
  const items = db.feedback.filter(
    (f) =>
      f.workspaceId === workspace.id &&
      new Date(f.createdAt).getTime() >= now - days * 86400000,
  );
  const untriaged = db.feedback.filter(
    (f) => f.workspaceId === workspace.id && !f.triaged,
  ).length;
  async function triage() {
    setTriaging(true);
    try {
      await new Promise((r) => setTimeout(r, 1800));
      await mutate({ type: "triage", workspaceId: workspace.id });
      toast(
        `${untriaged} feedback item${untriaged === 1 ? "" : "s"} categorized. Your inbox just got smarter.`,
      );
    } catch {
    } finally {
      setTriaging(false);
    }
  }
  function exportCsv() {
    const keys = [
      "title",
      "customerEmail",
      "category",
      "sentiment",
      "status",
      "rating",
      "createdAt",
      "content",
    ] as const;
    const escape = (value: unknown) => {
      let s = String(value);
      if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
      return `"${s.replaceAll('"', '""')}"`;
    };
    const text = [
      keys.join(","),
      ...items.map((f) => keys.map((k) => escape(f[k])).join(",")),
    ].join("\r\n");
    const url = URL.createObjectURL(
      new Blob(["\ufeff" + text], { type: "text/csv;charset=utf-8;" }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = `feedbackpulse-${workspace.slug}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast(`${items.length} feedback items exported`);
  }
  return (
    <>
      <div className="breadcrumb">
        Workspace <span>/</span>{" "}
        <span className="text-slate-600">
          {mode === "overview"
            ? "Overview"
            : mode === "feedback"
              ? "Feedback inbox"
              : "Analytics"}
        </span>
      </div>
      <div className="page-heading">
        <div>
          <div className="mb-2 flex items-center gap-2">
            <h1>
              {mode === "overview"
                ? "Your customers. Your next big idea."
                : mode === "feedback"
                  ? "Good products start with listening."
                  : "Find the story in your feedback."}
            </h1>
            {mode === "overview" && <span className="greeting-spark">✳</span>}
          </div>
          <p>
            {mode === "overview"
              ? "Here’s the pulse of your customer feedback. Let’s make it count."
              : mode === "feedback"
                ? "Every bug, bright idea, and kind word. All in one place."
                : "A clearer picture of what your customers love, need, and want next."}
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button onClick={exportCsv}>
            <Download size={14} />
            Export
          </Button>
          <Button variant="primary" onClick={() => setAddOpen(true)}>
            <Plus size={15} />
            Add feedback
          </Button>
        </div>
      </div>
      <div className="section-toolbar">
        <div className="flex items-center gap-5">
          <span className="section-tab">
            {mode === "overview"
              ? "Overview"
              : mode === "analytics"
                ? "Customer insights"
                : "All feedback"}
          </span>
          <span className="hidden text-[11px] text-slate-400 sm:inline">
            A little listening goes a long way.
          </span>
        </div>
        <div className="date-select">
          <CalendarDays size={13} />
          <select
            aria-label="Date range"
            value={days}
            onChange={(e) => setDays(Number(e.target.value))}
          >
            <option value={7}>Last 7 days</option>
            <option value={30}>Last 30 days</option>
            <option value={90}>Last 90 days</option>
            <option value={365}>Last year</option>
          </select>
        </div>
      </div>
      {mode !== "feedback" && (
        <>
          <Stats items={items} days={days} />
          <div className="chart-grid">
            <Trend items={items} days={days} />
            <Insight items={items} />
          </div>
        </>
      )}
      {mode === "analytics" ? (
        <Breakdown items={items} />
      ) : (
        <>
          <div className="triage-banner">
            <span className="triage-icon">
              <Sparkles size={17} />
            </span>
            <div>
              <p className="text-xs font-medium text-slate-700">
                Less sorting. More understanding.
              </p>
              <p className="mt-1 text-[10px] text-slate-500">
                Let AI find the sentiment and category in every piece of
                feedback.
              </p>
            </div>
            <Button
              className="ml-auto shrink-0 border-violet-200 bg-white text-brand"
              onClick={triage}
              loading={triaging}
              disabled={untriaged === 0}
            >
              {!triaging && <Sparkles size={13} />}
              <span className="hidden sm:inline">
                {triaging
                  ? "Analyzing feedback…"
                  : untriaged === 0
                    ? "All caught up"
                    : "AI Triage & Categorize"}
              </span>
              <span className="sm:hidden">
                {triaging ? "Triaging…" : "AI Triage"}
              </span>
              {!triaging && untriaged > 0 && (
                <span className="rounded bg-violet-100 px-1.5 text-[10px]">
                  {untriaged}
                </span>
              )}
            </Button>
          </div>
          <FeedbackHub
            key={workspace.id}
            items={items}
            full={mode === "feedback"}
          />
        </>
      )}
      <Modal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        title="A new voice in your inbox"
      >
        <FeedbackForm
          key={workspace.id + (addOpen ? "open" : "closed")}
          compact
          onSubmitted={() => setAddOpen(false)}
        />
      </Modal>
    </>
  );
}
