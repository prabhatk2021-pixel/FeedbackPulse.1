import type { Metadata } from "next";
import { Provider } from "@/components/provider";
import { Shell } from "@/components/shell";
import "./globals.css";
import { getDb } from "@/lib/store";
export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "FeedbackPulse — Every voice, a possibility",
  description:
    "Your customer feedback, beautifully connected. Listen, understand, and build what matters.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <Provider initialDb={structuredClone(getDb())} initialNow={Date.now()}>
          <Shell>{children}</Shell>
        </Provider>
      </body>
    </html>
  );
}
