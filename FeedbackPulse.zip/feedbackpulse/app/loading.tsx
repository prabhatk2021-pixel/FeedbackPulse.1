export default function Loading() {
  return (
    <div
      className="animate-pulse space-y-6 py-7"
      aria-label="Loading workspace"
    >
      <div className="h-7 w-1/3 rounded bg-slate-200" />
      <div className="grid grid-cols-2 gap-5 lg:grid-cols-4">
        {[0, 1, 2, 3].map((n) => (
          <div className="h-36 rounded-xl bg-slate-200/60" key={n} />
        ))}
      </div>
      <div className="h-64 rounded-xl bg-slate-200/60" />
      <div className="h-80 rounded-xl bg-slate-200/60" />
    </div>
  );
}
