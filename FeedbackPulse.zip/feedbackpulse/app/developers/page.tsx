import { Developers } from "@/components/developers";
export default function Page() {
  return <Developers />;
}
