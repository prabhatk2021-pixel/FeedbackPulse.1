import { NextResponse } from "next/server";
import { getDb, mutateDb, submissionSchema } from "@/lib/store";
import { readJson, checkSubmissionLimit, RequestError } from "@/lib/http";
const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-API-Key",
};
export async function OPTIONS() {
  return new Response(null, { status: 204, headers });
}
export async function POST(request: Request) {
  try {
    const key = request.headers.get("x-api-key");
    const workspace = getDb().workspaces.find((w) => w.apiKey === key);
    if (!workspace) throw new RequestError("Invalid workspace token", 401);
    checkSubmissionLimit(workspace.id);
    const body = await readJson(request);
    if (!body || typeof body !== "object" || Array.isArray(body))
      throw new RequestError("Expected a JSON object", 400);
    const parsed = submissionSchema.safeParse({
      ...body,
      workspaceId: workspace.id,
    });
    if (!parsed.success)
      throw new RequestError(parsed.error.issues[0].message, 400);
    const db = mutateDb({ type: "submit", ...parsed.data });
    return NextResponse.json(
      { id: db.feedback[0].id, status: "received" },
      { status: 201, headers },
    );
  } catch (error) {
    const status = error instanceof RequestError ? error.status : 400;
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Invalid request body",
      },
      {
        status,
        headers: {
          ...headers,
          ...(status === 429 ? { "Retry-After": "60" } : {}),
        },
      },
    );
  }
}
