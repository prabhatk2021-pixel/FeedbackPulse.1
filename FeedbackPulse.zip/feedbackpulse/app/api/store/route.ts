import { NextResponse } from "next/server";
import { commandSchema, getDb, mutateDb } from "@/lib/store";
import { readJson, RequestError } from "@/lib/http";
export const dynamic = "force-dynamic";
export async function GET() {
  return NextResponse.json(getDb(), {
    headers: { "Cache-Control": "no-store" },
  });
}
export async function POST(request: Request) {
  try {
    const origin = request.headers.get("origin");
    const allowedHosts = [
      request.headers.get("host"),
      request.headers.get("x-forwarded-host"),
    ];
    if (origin && !allowedHosts.includes(new URL(origin).host))
      throw new RequestError("Invalid origin", 403);
    const parsed = commandSchema.safeParse(await readJson(request));
    if (!parsed.success)
      throw new RequestError(parsed.error.issues[0].message, 400);
    return NextResponse.json(mutateDb(parsed.data));
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Unable to update store",
      },
      { status: error instanceof RequestError ? error.status : 400 },
    );
  }
}
