import { Checkout } from "@/components/billing";
export default function Page() {
  return <Checkout />;
}
