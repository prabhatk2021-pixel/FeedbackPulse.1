import { WidgetDemo } from "@/components/widget-demo";
export default function Page() {
  return <WidgetDemo />;
}
