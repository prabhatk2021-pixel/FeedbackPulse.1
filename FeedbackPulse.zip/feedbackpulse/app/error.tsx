"use client";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <div className="py-28 text-center">
      <h1 className="text-2xl font-semibold">
        We lost the pulse for a moment.
      </h1>
      <p className="my-4 text-sm text-slate-500">
        Something unexpected happened. Try loading this page again.
      </p>
      <button onClick={reset} className="btn btn-primary">
        Try again
      </button>
    </div>
  );
}
