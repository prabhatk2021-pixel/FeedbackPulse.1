import Link from "next/link";
export default function NotFound() {
  return (
    <div className="py-28 text-center">
      <p className="text-sm font-medium text-brand">404 · A quiet corner</p>
      <h1 className="my-4 text-3xl font-semibold">
        This page isn’t in the conversation.
      </h1>
      <p className="mb-7 text-sm text-slate-500">
        Let’s get you back to your customer feedback.
      </p>
      <Link href="/" className="btn btn-primary">
        Back to overview
      </Link>
    </div>
  );
}
