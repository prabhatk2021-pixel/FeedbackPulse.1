import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { brand: "#7461db" },
      boxShadow: { card: "0 2px 5px rgba(25,25,45,.025)" },
    },
  },
  plugins: [],
} satisfies Config;
